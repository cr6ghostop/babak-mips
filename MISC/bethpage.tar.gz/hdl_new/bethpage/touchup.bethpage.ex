1
i

.
1
r!$PROJ_DIR/tools/gen_module/auto_header
/\.xtxd *(p0_xtxd.*\/\/ nwk_port\.out nwk_port
i
`ifdef BPX_ONLY
`else
.
+2
a
`endif
.
/\.xtxd *(p1_xtxd.*\/\/ nwk_port\.out nwk_port
i
`ifdef BPX_ONLY
`else
.
+2
a
`endif
.
/\.gmii_txd *(p0_gmii_txd
+1,+5w!tmp
a
`ifdef BPX_ONLY
.
r tmp
a
`else
    `ifdef XGMII_IF
    `else
.
/\.xrxc *(p0_xrxc
a
    `endif
`endif
`ifdef ALTERA
    .fp_xtxd             (fp_p0_xtxd                  ),
    .fp_xtxc             (fp_p0_xtxc                  ),
    .fp_xrxd             (fp_p0_xrxd                  ),
    .fp_xrxc             (fp_p0_xrxc                  ),
    .fp_ctrl             (fp_p0_ctrl                  ),
`endif
.

/\.gmii_txd *(p1_gmii_txd
+1,+5w!tmp
a
`ifdef BPX_ONLY
.
r tmp
a
`else
    `ifdef XGMII_IF
    `else
.
/\.xrxc *(p1_xrxc
a
    `endif
`endif
`ifdef ALTERA
    .fp_xtxd             (fp_p1_xtxd                  ),
    .fp_xtxc             (fp_p1_xtxc                  ),
    .fp_xrxd             (fp_p1_xrxd                  ),
    .fp_xrxc             (fp_p1_xrxc                  ),
    .fp_ctrl             (fp_p1_ctrl                  ),
`endif
.




/nwk_port	port_1
i
`ifdef ONEPORT_FPGA
  nwk_port_stub  port_1 (
`else
.
/nwk_port	port_1
a
`endif
.

/\.pad_pcie_sd_rxn
i
`ifdef ALTERA        
    .clk_pclk            (clk_pclk                    ),  // mbu.in mbu
    .clk_pclk_div2       (clk_pclk_div2               ),  // mbu.in mbu
    .pciesd_cmu_lock     (pciesd_cmu_lock             ),  // mbu.in mbu
    .phy_mac_rxdata      (phy_mac_rxdata              ),  // mbu.in mbu
    .phy_mac_rxdatak     (phy_mac_rxdatak             ),  // mbu.in mbu
    .phy_mac_rxvalid     (phy_mac_rxvalid             ),  // mbu.in mbu
    .phy_mac_rxstatus    (phy_mac_rxstatus            ),  // mbu.in mbu
    .phy_mac_rxelecidle  (phy_mac_rxelecidle          ),  // mbu.in mbu
    .phy_mac_phystatus   (phy_mac_phystatus           ),  // mbu.in mbu
    .phy_cfg_status      (phy_cfg_status              ),  // mbu.in mbu
    
    .mac_phy_txdata      (mac_phy_txdata              ),  // mbu.out mbu
    .mac_phy_txdatak     (mac_phy_txdatak             ),  // mbu.out mbu
    .mac_phy_txdetectrx_loopback( 
                           mac_phy_txdetectrx_loopback),  // mbu.out mbu
    .mac_phy_txelecidle  (mac_phy_txelecidle          ),  // mbu.out mbu
    .mac_phy_txcompliance(mac_phy_txcompliance        ),  // mbu.out mbu
    .mac_phy_rxpolarity  (mac_phy_rxpolarity          ),  // mbu.out mbu
    .mac_phy_powerdown   (mac_phy_powerdown           ),  // mbu.out mbu
    .cfg_phy_control     (cfg_phy_control             ),  // mbu.out mbu
    .mac_phy_rate        (mac_phy_rate                ),  // mbu.out mbu 
    .mac_phy_txdeemph    (mac_phy_txdeemph            ),  // mbu.out mbu
    .mac_phy_txmargin    (mac_phy_txmargin            ),  // mbu.out mbu
    .mac_phy_txswing     (mac_phy_txswing             ),  // mbu.out mbu
    .xmlh_ltssm_state    (xmlh_ltssm_state            ),  // mbu.out mbu
    .clksys_50_buf       (clksys_50_buf               ),  // mbu.out mbu
`else    
.
/\.pad_pcie_sd_txp
a
`endif
.

g/.*\.fp_xrxd.*(fp_xrxd/s/^/\/\//g
g/.*\.fp_xrxc.*(fp_xrxc/s/^/\/\//g
g/.*\.fp_xtxd.*(fp_xtxd/s/^/\/\//g
g/.*\.fp_xtxc.*(fp_xtxc/s/^/\/\//g
g/.*\.fp_ctrl.*(fp_ctrl/s/^/\/\//g


.
/BUMP_PCIE_RXN\,
i
//------------------------------------------------------------------------------
// XAUI SERDES SERIAL TRANSMIT/RECEIVE (FPGA)
//------------------------------------------------------------------------------
`ifdef ALTERA
      input [63:0]        fp_p0_xrxd,       // [synspec: cd=vir_clksys_156]  pcs receive data to MAC 
      input [7:0]         fp_p0_xrxc,       // [synspec: cd=vir_clksys_156]  pcs receive ctrl to MAC 
      output logic [63:0] fp_p0_xtxd,       // [synspec: cd=vir_clksys_156]  pcs transmit data from MAC
      output logic [7:0]  fp_p0_xtxc,       // [synspec: cd=vir_clksys_156]  pcs transmit ctrl from MAC
      input [11:0]        fp_p0_ctrl,

      input [63:0]        fp_p1_xrxd,       // [synspec: cd=vir_clksys_156]  pcs receive data to MAC 
      input logic [7:0]   fp_p1_xrxc,       // [synspec: cd=vir_clksys_156]  pcs receive ctrl to MAC 
      output logic [63:0] fp_p1_xtxd,       // [synspec: cd=vir_clksys_156]  pcs transmit data from MAC
      output logic [7:0]  fp_p1_xtxc,       // [synspec: cd=vir_clksys_156]  pcs transmit ctrl from MAC
      input [11:0]        fp_p1_ctrl,
//------------------------------------------------------------------------------
// PCIE SERDES SERIAL TRANSMIT/RECEIVE
//------------------------------------------------------------------------------
      input             clk_pclk,
      input             clk_pclk_div2,

      input             pciesd_cmu_lock,
      input [127:0]     phy_mac_rxdata,
      input [15:0]      phy_mac_rxdatak,
      input [7:0]       phy_mac_rxvalid,
      input [23:0]      phy_mac_rxstatus,
      input [7:0]       phy_mac_rxelecidle,
      input [7:0]       phy_mac_phystatus,
      input [31:0]      phy_cfg_status,
      output logic  [127:0] mac_phy_txdata,
      output logic  [15:0]  mac_phy_txdatak,
      output logic  [7:0]   mac_phy_txdetectrx_loopback,
      output logic  [7:0]   mac_phy_txelecidle,
      output logic  [7:0]   mac_phy_txcompliance,
      output logic  [7:0]   mac_phy_rxpolarity,
      output logic  [1:0]   mac_phy_powerdown,
      output logic  [63:0]  cfg_phy_control,
      output logic          mac_phy_rate, 
      output logic          mac_phy_txdeemph,
      output logic  [2:0]   mac_phy_txmargin,
      output logic          mac_phy_txswing,
      output logic  [4:0]   xmlh_ltssm_state,
      input [16:0]          fpga_straps,
      output logic          clksys_50_buf,
      inout             PAD_I2C_SDA2,
      inout             PAD_I2C_SCL2,
      output            PAD_MDC2,
      inout             PAD_MDIO2,
`else
.
/BUMP_PCIE_TXP\,
a
`endif
.

/bpx_0.*(
i
`ifdef B0_FPGA
  bpx_stub bpx_0 (
`else
.
/bpx_0.*(
a
`endif
.

/bpx_1.*(
i
`ifdef FPGA_SIM
  `ifdef PLATFORM_M
    bpx_stub bpx_1 (
  `else
    bpx bpx_1 (
  `endif
`else
  `ifdef ONEPORT_FPGA
    bpx_stub bpx_1 (
  `else
    `ifdef PLATFORM_M
      bpx_stub bpx_1 (
    `else
.
/bpx_1.*(
a
    `endif
  `endif
`endif
.

/mc_jtag_w0\,
i
`ifdef ALTERA
.
/mc_jtag_r0\,
a
`endif
.

/\.mc_jtag_w0
i
`ifdef ALTERA
.
/\.mc_jtag_r0
a
`endif
.
/\.PAD_I2C_SDA2
i
`ifdef ALTERA

.
/\.mc_jtag_w1
a
`endif
.

g/logic.*p[01]_gmii_txd;/s/logic/wire/g
g/logic.*p[01]_gmii_rxd;/s/logic/wire/g
g/logic.*p[01]_gcrs_i;/s/logic/wire/g
g/logic.*p[01]_gcol_i;/s/logic/wire/g
g/logic.*p[01]_xrxd;/s/logic/wire/g
g/logic.*p[01]_xrxc;/s/logic/wire/g
g/logic.*p[01]_xtxd;/s/logic/wire/g
g/logic.*p[01]_xtxc;/s/logic/wire/g
g/logic.*fpga_straps/s/^/\/\//g

g/^[ 	]*logic.*PAD_/d

w!
