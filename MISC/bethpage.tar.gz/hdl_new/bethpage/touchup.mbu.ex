1
i

.
1
r!$PROJ_DIR/tools/gen_module/auto_header
?assign 
a
`ifndef ALTERA
    assign phy_mac_phystatus = {8{pcie_sd_phystatus}};
`ifdef PIPE_IF
   assign pciesd_cmu_lock = 1'b1;
`endif
`endif
.

/\.pad_pcie_sd_txn
a
`ifdef PIPE_IF
`else
.
/\.phy_mac_phystatus *(pcie_sd_phystatus
a
`endif
.
/\input.*mc_jtag_r0
i
`ifdef ALTERA
.
/\input.*mc_jtag_r0
a
   input    pciesd_cmu_lock,
   output [4:0] xmlh_ltssm_state,
`endif
.

/\logic.*pciesd_cmu_lock
i
`ifndef ALTERA
.
/\logic.*pciesd_cmu_lock
a
`endif
.
/\logic.*xmlh_ltssm_state
i
`ifndef ALTERA
.
/\logic.*xmlh_ltssm_state
a
`endif

.
/\mc_jtag_w0\,
i
`ifdef ALTERA
.
/\mc_jtag_w1\,
a
`endif

.
g/logic.*phy_mac_rxdata;/s/logic/wire/g
g/logic.*phy_mac_rxdatak;/s/logic/wire/g
g/logic.*phy_mac_rxvalid;/s/logic/wire/g
g/logic.*phy_mac_rxstatus;/s/logic/wire/g
g/logic.*phy_mac_rxelecidle;/s/logic/wire/g
g/logic.*mac_phy_txdata;/s/logic/wire/g
g/logic.*mac_phy_txdatak;/s/logic/wire/g
g/logic.*mac_phy_txdetectrx_loopback;/s/logic/wire/g
g/logic.*mac_phy_txelecidle;/s/logic/wire/g
g/logic.*mac_phy_txcompliance;/s/logic/wire/g
g/logic.*mac_phy_rxpolarity;/s/logic/wire/g
g/logic.*mac_phy_powerdown;/s/logic/wire/g
g/logic.*mac_phy_rate;/s/logic/wire/g
g/logic.*mac_phy_txdeemph;/s/logic/wire/g
g/logic.*mac_phy_txmargin;/s/logic/wire/g
g/logic.*mac_phy_txswing;/s/logic/wire/g
g/logic.*clk_pclk;/s/logic/wire/g
g/logic.*clk_pclk_div2;/s/logic/wire/g
g/logic.*pcie_sd_phystatus;/s/logic/wire/g
g/logic.*phy_mac_phystatus;/s/logic/wire/g

/input.*pcie_sd_jtag_in
a
`ifdef ALTERA
`ifdef FPGA_BUILD
    output logic    clksys_50_buf,
`endif
    input           clk_pclk,
    input           clk_pclk_div2,
    input   [127:0] phy_mac_rxdata,
    input   [15:0]  phy_mac_rxdatak,
    input   [7:0]   phy_mac_rxvalid,
    input   [23:0]  phy_mac_rxstatus,
    input   [7:0]   phy_mac_rxelecidle,
    input   [7:0]   phy_mac_phystatus,
    input   [31:0]  phy_cfg_status,
    output  [127:0] mac_phy_txdata,
    output  [15:0]  mac_phy_txdatak,
    output  [7:0]   mac_phy_txdetectrx_loopback,
    output  [7:0]   mac_phy_txelecidle,
    output  [7:0]   mac_phy_txcompliance,
    output  [7:0]   mac_phy_rxpolarity,
    output  [1:0]   mac_phy_powerdown,
    output  [63:0]  cfg_phy_control,
    output          mac_phy_rate, 
    output          mac_phy_txdeemph,
    output  [2:0]   mac_phy_txmargin,
    output          mac_phy_txswing,
`endif
.

/pcie_sd_wrap.*pcie_sd_wrap
i
`ifdef ALTERA // in the BO and HS FPGA we tie off a fair bit if logic & don't pull in PCIE SERDES
    assign pad_pcie_sd_txp      = 8'h0;
    assign pad_pcie_sd_txn      = 8'h0;
    
    assign pcie_sd_mc_ack       = mc_gblrg_req & mc_gblrg_addr[27] & (mc_gblrg_addr[23:10]=={14{1'b0}}); // ack = request
    assign pcie_sd_mc_rdata     = 32'b0;    // Read data from PCIE SERDES to MC (sync to clksys_125) - wire OR'd
    assign pcie_sd_dtb          = 2'b0;
    
    assign bist_ber_clear       = 1'b0;
    assign bist_force_err       = 1'b0;
    assign bist_rx_reset        = 1'b0;
    assign bist_tx_reset        = 1'b0;
    assign pciesd_dbg_out       = 32'h0;
    
    assign pcie_sd_ac_jtag_outn = 8'h0;
    assign pcie_sd_ac_jtag_outp = 8'h0;
    assign pcie_sd_jtag_out     = 8'h0;
    
    assign pcie_sd_sysclk_out   = 1'b0;
    assign pcie_sd_ready        = 1'b1;
    assign pcie_sd_coreclk_out  = 1'b0;
    assign l_rclk               = 8'h0;
    assign p0_phyreset_bar      = 1'b1;   // if this is 0, then core reset is held on and pcie core gets optimised away
    assign p0_pstate            = 2'h0;   // MAINfsm state in PCS - for debugging in simulation
    assign p0_wstate            = 2'h0;   // WAKEfsm state in PCS - for debugging in simulation
    
    assign pcie_sd_speed        = 1'b1;     // FPGA B0; simulate GEN2 at GEN1  gen1 1: gen2 

`else
.
/;
a
`endif
.

/\.L0_TX_BAND
i
`ifdef PIPE_IF
`else
.
/\.L0_TX_BAND
a
`endif
.

/\.pciesd_cmu_lock
i
`ifdef PIPE_IF
`else
.
/\.pciesd_cmu_lock
a
`endif
.

/\.phy_mac_rxdata.*ate_mac
i
`ifdef ALTERA
  .phy_mac_rxdata      (phy_mac_rxdata              ),
  .phy_mac_rxdatak     (phy_mac_rxdatak             ),
  .phy_mac_rxvalid     (phy_mac_rxvalid             ),
  .phy_mac_rxstatus    (phy_mac_rxstatus            ),
  .phy_mac_rxelecidle  (phy_mac_rxelecidle          ),
  .phy_mac_phystatus   (phy_mac_phystatus           ),
`else
.
/\.phy_mac_phystatus.*ate_mac
a
`endif
.

/wire.*\[127\:0\].*phy_mac_rxdata\;
i
`ifndef ALTERA
.
/wire.*\[1\:0\].*mac_phy_powerdown\;
a
`endif
.

/wire.*clk_pclk\;
i
`ifndef ALTERA
.

g/logic.*clksys_50_buf\;/d

/wire.*clk_pclk_div2\;
a
`endif
.

/\.mc_jtag_w0
i
`ifdef ALTERA
.
/\.mc_jtag_r0
a
`endif
.

/\.pserd_tx_band.*mc_top\.in
i
`ifdef ALTERA
    .pserd_tx_band  (1'b0), // temp change K.H.
`else
.
/\.pserd_tx_band
a
`endif // !ALTERA
.

/wire.*mac_phy_txdata;
i
`ifdef ALTERA
`else
.
/mac_phy_txswing;
a
`endif
.

/\.clksys_50_buf
i
`ifdef FPGA_BUILD
`ifdef ALTERA
.
/\.clk_pclk_div2
a
`endif
`endif
.

w!

