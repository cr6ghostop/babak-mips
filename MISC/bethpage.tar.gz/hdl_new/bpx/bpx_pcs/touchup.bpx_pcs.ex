/endmodule
i
`ifdef ASIC
spare_top #(3) spare_clk_mac ( /* synthesis syn_noprune = 1*/
    .rst_n      (sgmii_mac_clk_rst_n),
    .clk        (clk_mac)
);

spare_top #(7) spare_clksys_125 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_bpx_n),
    .clk        (clksys_125)
);

spare_top #(8) spare_clksys_156 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_bpx_n),
    .clk        (clksys_156)
);

spare_top #(1) spare_sfp_bpx_xaui_clk ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_bpx_n),
    .clk        (sfp_bpx_xaui_clk)
);

spare_top #(1) spare_clktx_125 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_bpx_n),
    .clk        (clktx_125)
);

spare_top #(6) spare_tbi_rclk ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_sgmii_n),
    .clk        (tbi_rclk)
);

spare_top #(2) spare_tbi_tclk ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_sgmii_n),
    .clk        (tbi_tclk)
);

spare_top #(2) spare_xaui_sd_rclk0 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xaui_sd_rclk[0])
);

spare_top #(6) spare_xaui_sd_tclk ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xaui_sd_tclk)
);

//spare_top #(1) spare_xfi_sd_rclk ( /* synthesis syn_noprune = 1*/
//    .rst_n      (xfi_sd_clksys_125_rst_n),
//    .clk        (xfi_sd_rclk)
//);
//
//spare_top #(1) spare_xfi_sd_tclk_out ( /* synthesis syn_noprune = 1*/
//    .rst_n      (xfi_sd_clksys_125_rst_n),
//    .clk        (xfi_sd_tclk_out)
//);

spare_top #(30) spare_xgbr_sd_rclk ( /* synthesis syn_noprune = 1*/
    .rst_n      (xgbr_sd_rclk_rst_n),
    .clk        (xgbr_sd_rclk)
);

spare_top #(27) spare_xgbr_sd_tclk ( /* synthesis syn_noprune = 1*/
    .rst_n      (xgbr_sd_tclk_rst_n),
    .clk        (xgbr_sd_tclk)
);

spare_top #(22) spare_xgxs_sd_rclk0 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xgxs_sd_rclk[0])
);

spare_top #(5) spare_xgxs_sd_rclk1 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xgxs_sd_rclk[1])
);

spare_top #(5) spare_xgxs_sd_rclk2 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xgxs_sd_rclk[2])
);

spare_top #(5) spare_xgxs_sd_rclk3 ( /* synthesis syn_noprune = 1*/
    .rst_n      (rst_xgxs_n),
    .clk        (xgxs_sd_rclk[3])
);
`endif
.
w!
