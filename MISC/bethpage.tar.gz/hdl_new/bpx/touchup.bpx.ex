/input.*sfp_bpx_xaui_data
a
`ifdef ALTERA
    input [63:0]        fp_xrxd,       // [synspec: cd=vir_clksys_156]  pcs receive data to MAC 
    input [7:0]         fp_xrxc,       // [synspec: cd=vir_clksys_156]  pcs receive ctrl to MAC 
    output logic [63:0] fp_xtxd,       // [synspec: cd=vir_clksys_156]  pcs transmit data from MAC
    output logic [7:0]  fp_xtxc,       // [synspec: cd=vir_clksys_156]  pcs transmit ctrl from MAC
    input [11:0]        fp_ctrl,       // [synspec: cd=vir_clksys_156]  pcs ctrl from top
`endif
.
w!
