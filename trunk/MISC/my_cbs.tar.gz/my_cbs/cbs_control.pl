#!/usr/bin/perl
################################################################################
# A continuous build system for the Siena RTL
# This long lived process looks for changes from the DB
#  runs a sequence of tests and writes the result to a database
# This script is designed to be run by the "cbs" shell wrapper which guarantees
#  that there is only one testing instance
#
# Robert Stonehouse
# Feb 2008
################################################################################

use lib "/home/rjs/etc/perl-lib";
use strict;
use warnings;
use DBI;
use Time::ParseDate;
use File::Temp qw/ tempfile tempdir /;
use IPC::Open3;
use POSIX qw(strftime);

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";

my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");


my ($select_checkin, $select_to_rerun, $select_pend_min_max, $select_pend_run, $select_run);
my ($select_to_resched, $select_files, $select_backdep, $select_pend_gt, $select_special_dir);
my ($replace_test);
my ($update_resched_test, $update_resched_rc, $update_enable_test, $update_test_rc);
my ($update_badbackdep, $update_test_all);

my $last_status=""; # To help make the log more readable only report changes
my $last_checkin=0; # Try to catch infinite scheduling loops
my $checkin_repeats = 0;

################################################################################


# Reschedule needed test parts
sub test_reschedule_as_needed {
  my ($svnrev) = @_;

  # For safety
  cbs_common::kill_grid_jobs();

  if ($cbs_config::release eq "running") {
    foreach my $file (glob("$cbs_config::joblogs/*")) {
      unlink($file) || die("$!");
    }
    foreach my $file (glob("$cbs_config::jobcmds/*")) {
      unlink($file) || die("$!");
    }
  }
  
  $select_to_resched->execute($svnrev-$cbs_config::min_checkin-1) || die("$!");
  while (my ($rid,$rtesttype) = $select_to_resched->fetchrow_array()) {

    my $_rid = $rid;
    my $_rtesttype = $rtesttype;

    while ($rtesttype && ($rtesttype ne "none")) {      
      $update_resched_test->execute(time(),time(),$svnrev,$rtesttype) || die("$!");

      if ($rtesttype=~/^special_/) {
	# For special_tests find the reserve dependancy from the test
	my ($special_id) = ($rtesttype=~/^special_(\d+)/);
	$select_backdep->execute($special_id) || die("$!");
	($rtesttype)=$select_backdep->fetchrow_array();
	
      } else {
	# Else look it up in the test_target hash
	if ($rtesttype=~/^smoke_/) {
	  $rtesttype = "smoke";
	  # Need to re-enable the smoke psuedo-test as well
	  $update_resched_test->execute(time(),time(),$svnrev,$rtesttype) || die("$!");
	}
	$rtesttype = $cbs_config::back_deps{"$rtesttype"}
      }

      ($rtesttype eq $cbs_config::first_test_for_new_update) || $rtesttype || die("Unknown backwards deps for '$rtesttype' orig $_rid $_rtesttype");
    }
  }

  # Run the first test - everything else will happen later
  $update_enable_test->execute($svnrev,$cbs_config::first_test_for_new_update) || die("$!");
}


# Return false if test unnecessary due to types of files updated
sub test_necessary {
  my ($testid, $svnrev, $testtype) = @_;
  my $onlyfor = $cbs_config::test_target{"$testtype"}{'onlyfor'};
  my $oneinn = $cbs_config::test_target{"$testtype"}{'oneinn'};
  my $test_needed = 0;

  if ($cbs_config::release eq "testing") {
    return 1;
  }
  if ($oneinn) {
    if ((int($svnrev) % $oneinn) == 0) {
      # Need to test regardless of other filters
      return 1;
    } else {
      print "Not testing $svnrev $testtype due to oneinn in config\n";
      return 0;
    }
  }

  if (!$onlyfor) {
    return 1;
  }

  # See if the 'onlyfor' reg-exp matches anything
  $select_files->execute($svnrev) or die;
  my ($files) = $select_files->fetchrow_array();
  my @files = split /\n/, $files;

  foreach my $file (@files) {
    foreach my $onlyforone (split /,/,$onlyfor) {
      if ($file=~m|^$cbs_config::svnmod/$onlyforone|) { $test_needed=1; };
    }
  }

  return $test_needed;
}


# Reads the smoke list and inserts the tests
sub schedule_smoke {
  my ($checkin) = @_;

  open(SMOKE,"<$cbs_config::top/dv/tb/tests/tcase/_smoke.simlist") || die("$!");
  while (my $smktest = <SMOKE>) {
    chop $smktest;
    $smktest="smoke_$smktest";
    cbs_common::replace_test($checkin, $smktest);
  }
  close(SMOKE);
}


# Make a license request
sub make_lic_req {
  my ($testtype, $canontype) = @_;  
  my $test_lic = $cbs_config::test_target{$canontype}->{'lic'};

  if (my ($sid) = ($testtype=~/^special_(\d+)/)) {
    $select_special_dir->execute($sid) || die("$!");
    my ($sdir) = $select_special_dir->fetchrow_array();

    if ($sdir=~/mbist/) {
      if ($test_lic!~/lic_dw_reg=1/) {
	if ($test_lic ne "") {
	  $test_lic.=",";
	}
	$test_lic.="lic_dw_reg=1";
      }
    }
  }

  return $test_lic;
}


# Run a job on the grid
sub run_job {
  my ($testid, $testtype, $svnrev, $canontype) = @_;

  if ($testtype eq "smoke") {
    schedule_smoke($svnrev);
    # This is a psuedo test
    $update_test_rc->execute(time(), time(), $cbs_config::rc_unnecessary, $testid);
  } else {

    my $preopts="";
    # TODO restore this -  && !$cbs_config::test_target{$canontype}{'nogrid'})  {
    if ($cbs_config::usegrid) {
      my $gridqueue = $cbs_config::default_queue;
      my $test_queue = $cbs_config::test_target{$canontype}->{'queue'};
      my $test_lic = make_lic_req($testtype, $canontype);
      
      my ($logdir, $logfile) = cbs_common::get_log_names($svnrev, $testtype);
      if (-f "$logfile") {
	unlink("$logfile") or die("$!");
      }
      if (-f "$logfile.gz") {
	unlink("$logfile.gz") or die("$!");
      }

      $preopts="$cbs_config::qsub -j y -o $logfile -q ";
      $preopts.=($test_queue ? $test_queue : $cbs_config::default_queue);
      if ($test_lic) {
	$preopts.=" -l '$test_lic'";
      }
    }

    my $jobcmd = "$cbs_config::run_one $cbs_config::release $testid $svnrev $testtype";
    my $jobfile = "$cbs_config::jobcmds/$svnrev.$testtype";
    my $rand_port=int(rand(28000))+1024;
    my $jobid = 0;
    open(JOB,">$jobfile") || die("$!: in opening '$jobfile'");
    print JOB "dproj $cbs_config::proj\n";
    print JOB "setenv DW_LICENSE_OVERRIDE Designware-Regression\n";
    print JOB "setenv PROJ_DIR $cbs_config::top\n";
    print JOB "setenv PATH $cbs_config::top/tools/bin:";
    my $perl = 'my $path=$ENV{"PATH"}; $path=~s|/projects/SFL9021AA/Work/dev/sw/v5/scripts:||g; print $path;';
    print JOB '`perl -e\'',$perl,'\'`',"\n";
    print JOB "setenv SFC_COSIM_PORT $rand_port\n";
    print JOB "setenv FLEXLM_DIAGNOSTICS 3\n";
    print JOB "setenv DW_WAIT_LICENSE 1\n";
    print JOB "setenv DW_LICENSE_OVERRIDE DESIGNWARE-REGRESSION\n";
    print JOB "echo starting\n";
    print JOB "date\n";
    print JOB "hostname --fqdn \n";
    print JOB "lmstat -a -c 26585\@10.20.40.14 | egrep -i 'runtime|regression'\n";
    print JOB "$jobcmd\n";
    print JOB "echo ending\n";
    print JOB "date\n";
    close(JOB);

    # SUBMIT (or run for !usegrid)
    if ($cbs_config::usegrid) {
      my $job = "$preopts $jobfile";
      print "About to submit '$job' which is '$jobcmd'\n";

      my $output = `$job`;
      print $output;
      
      # Output from qsub
      # Your job 430955 ("cbs_running") has been submitted
      ($jobid) = ($output=~/^Your job (\d+) \(.*?\) has been submitted/);
      ($jobid) || die("Could not extract job number from '$output'");
    } else {
      print `$jobcmd`;
    }
    my $rc = $?;
    print "Submitted $testid $svnrev $testtype jobid $jobid rc=$rc\n";

    $update_test_all->execute(time(), 0, $cbs_config::rc_pendgrid, $jobid, $testid);
  }
}


# Inlcusive
sub rand_min_max {
  my ($min, $max) = @_;
  return $min + int(rand($max - $min + 1));
}


# Launch all jobs that are pending
sub launch_pend_jobs {
  my ($checkin, $max_jobs) = @_;

  # Launch pending jobs - note new jobs might get added
  while ($max_jobs > 0) {

    $select_pend_min_max->execute($checkin) || die("$!");
    my ($id_min, $id_max) = $select_pend_min_max->fetchrow_array();
    if (!$id_min) {
      return;
    }

    my $id_rand = rand_min_max($id_min, $id_max);    
    print "id_rand $id_rand\n";

    $select_pend_gt->execute($checkin, $id_rand) || die("$!");
    my ($testid, $testtype, $svnrev) = $select_pend_gt->fetchrow_array();
    my $canontype = (($testtype=~/^special_/) ? "special" : $testtype);

    print "Found pending test=$testid '$testtype'\n";

    # Check the test is of known type, necessary and not disabled
    if ($testtype!~/^smoke_/ && $testtype!~/^special_/) {
      if (!$cbs_config::test_target{$testtype}) {
	print "Unknown test '$testtype' for $testid\n";
	$update_test_rc->execute(time(), time(), $cbs_config::rc_unknowntest, $testid);
	next;
      }
      
      # Valid test type
      if ($cbs_config::test_target{$canontype}->{'disabled'} ||
	  ($cbs_config::test_target{$canontype}->{'disabled_in_testing'} && 
	   $cbs_config::release eq "testing")) {
	print "Test disabled for $testid\n";
	$update_test_rc->execute(time(), time(), $cbs_config::rc_disabled, $testid);
	next;
      }
      
      if (!test_necessary($testid, $svnrev, $canontype)) {
	print "Test not necessary for $testid\n";
	cbs_common::sched_next_tests($testid,$svnrev,$canontype);
	$update_test_rc->execute(time(), time(), $cbs_config::rc_unnecessary, $testid);
	next;
      }
    }

    # Run the job(s)
    run_job($testid, $testtype, $svnrev, $canontype);
    $max_jobs--;
  }
}


# Picks a revision where there is some test parts that is pending
# Returns true if there are more tests to run (potentially)
sub test_untested_rev {
  my ($min_checkin) = @_;
  my $nothing_to_do = 0;
  my $timestr =  POSIX::strftime("%T",gmtime(time()));

  # Select a revision
  $select_checkin->execute($min_checkin) || die("$!");
  my ($checkin) = $select_checkin->fetchrow_array();
  my $status = "";

  if (!$checkin) {
    # Nothing to do
    $status="Nothing to do - min to consider is $min_checkin\n";
    if ($status ne $last_status) {
      print "$timestr> $status";
      $last_status=$status;
    }
    return 0;
  }

  if ($checkin == $last_checkin) {
    $checkin_repeats++;
    if ($checkin_repeats >= $cbs_config::max_checkin_repeats) {
      $update_badbackdep->execute(time(), time(), $checkin) || die("$!");
    }
  } else {
    $checkin_repeats = 0;
  }
  $last_checkin = $checkin;

  print "$timestr> Now working on SVN ID $checkin ...\n";
  test_reschedule_as_needed($checkin);

  # Wait until there are no more tests to run, pending or running
  while (1) {

    $select_pend_run->execute($checkin) || die("$!");
    if ($select_pend_run->rows == 0) {
      # counter allows for races with database updates
      $nothing_to_do++;
      $status="Waiting ($nothing_to_do) ...\n";
      if ($status ne $last_status) {
	print "$timestr> $status";
	$last_status=$status;
      }
      if ($nothing_to_do == 4) {
	# This is the end of testing a revision
	cbs_common::save_coverage_results($checkin);
	cbs_common::garden_coverage_results($dbh);
	cbs_common::fixup_coverage_commands($dbh, $checkin);
	return 1;
      }
    } else {
      $nothing_to_do = 0
    }

    # Deal with jobs that do not end as expected
    my %jobs = cbs_common::get_grid_jobs();
    my $num_jobs = scalar(keys(%jobs));

    $select_run->execute($checkin) || die("$!");
    if (%jobs) {
      $status=sprintf("%d jobs | ", $select_run->rows);
      while (my ($rid,$rtesttype, $jobid) = $select_run->fetchrow_array()) {
	$status.="$rid $rtesttype $jobid | ";
	if (!$jobs{$jobid}) {
	  $status.="[quit/error] ";
	  $update_test_rc->execute(time(), time(), $cbs_config::rc_gridfail, $rid);
	}
      }
      $status.="\n";
    }
    if ($status ne $last_status) {
      print "$timestr> $status";
      $last_status=$status;      
    }

    # Launch the jobs
    launch_pend_jobs($checkin, $cbs_config::grid_max_jobs - $num_jobs);

    # Wait a while to see if running jobs are finished or new jobs need starting
    sleep($cbs_config::dbpoll);
  }
  die("Never get here");
}


################################################################################

$|=1;

# Command line paring and sanity checks
(scalar(@ARGV) == 0) or die("usage: $0");

# Setup
cbs_common::make_backwards_deps(); 

# Test states | Name                      | Start  | End    | rc  |
#             | Running                   | time   | 0      |     |
#             | Done / Resched(inactive)  | time   | time   | 258 |   
#             | Pending / Resched(active) | 0      | 0      | 258 |


# checkins table
$select_files       = $dbh->prepare('SELECT files FROM checkins WHERE id=?') || die("$!");
# tests table
$replace_test       = $dbh->prepare("REPLACE INTO tests VALUES (0,?,?,0,0,256,0,0,'',0)") || die("$!");
# Offer to test all specials regardless of when requested
$select_checkin     = $dbh->prepare('SELECT checkin FROM tests WHERE (start_compile=0 OR rc=258) AND checkin>=? ORDER BY checkin DESC LIMIT 1') || die("$!");
$select_pend_min_max = $dbh->prepare('SELECT MIN(id), MAX(id) FROM tests WHERE checkin=? AND start_compile=0 AND end_compile=0') || die("$!");
$select_pend_gt     = $dbh->prepare('SELECT id,testtype,checkin FROM tests WHERE checkin=? AND start_compile=0 AND end_compile=0 AND id>=? ORDER BY id') || die("$!");
$select_pend_run    = $dbh->prepare('SELECT id,testtype,jobid FROM tests WHERE checkin=? AND end_compile=0') || die("$!");
$select_run         = $dbh->prepare('SELECT id,testtype,jobid FROM tests WHERE checkin=? AND start_compile>0 AND end_compile=0') || die("$!");
$select_to_resched  = $dbh->prepare('SELECT id,testtype FROM tests WHERE checkin>=? AND (end_compile=0 OR rc=258 OR rc=270)') || die("$!");
$update_test_rc     = $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=?, rc=? WHERE id=?') || die("$!");
$update_test_all    = $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=?, rc=?, jobid=? WHERE id=?') || die("$!");
$update_enable_test = $dbh->prepare('UPDATE tests SET start_compile=0, end_compile=0,rc=258 WHERE checkin=? AND testtype=?') || die("$!");
$update_resched_rc  = $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=?,rc=258 WHERE rc=259 OR rc=270') || die("$!");
$update_resched_test= $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=?,rc=258 WHERE checkin=? AND testtype=?') || die("$!");
$update_badbackdep  = $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=?,rc=272 WHERE checkin=? AND start_compile=0') || die("$!");
# special tests table
$select_backdep     = $dbh->prepare('SELECT backdep FROM special_tests WHERE id=?') || die("$!");
$select_special_dir = $dbh->prepare('SELECT dir FROM special_tests WHERE id=?') || die("$!");

# Remove running or pending jobs
cbs_common::kill_grid_jobs();
$update_resched_rc->execute(time(), time()) || die("$!");

while (1) {
  print "Getting info on latest revs...\n";
  my $min_checkin;
  do {
    $min_checkin = cbs_common::get_min_checkin();
  } while (test_untested_rev($min_checkin));

  # Nothing to do ... zzzzzz ....
  sleep($cbs_config::svnpoll);
}
