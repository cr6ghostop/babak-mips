#!/usr/bin/perl
#
# Web server component for a Siena Continuous Build System
#
# This script is only meant to be run from the cbs script
#
# Robert Stonehouse
# Feb 2008
#
use strict;
use warnings;

use lib "/home/rjs/etc/perl-lib";
use DBI;
use POSIX qw(strftime SIGCHLD);
use CGI qw/escapeHTML unescapeHTML/;

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";

{
  package MyWebServer;
  
  use HTTP::Server::Simple::CGI;
  use base qw(HTTP::Server::Simple::CGI);
  use File::Basename;

  my %dispatch = ('/latest'           => \&resp_latest,
		  '/main_iframe'      => \&resp_main_iframe,
		  '/special_iframe'   => \&resp_special_iframe,
		  '/recentend_iframe' => \&resp_recentend_iframe,
		  '/update_comment'   => \&resp_update_comment,
		  '/log'              => \&resp_log,
		  '/log_iframe'       => \&resp_log_iframe,
		  '/main_logs'        => \&resp_main_logs,
		  '/main_log'         => \&resp_main_log,
		  '/diff'             => \&resp_diff,
		  '/retest'           => \&resp_retest,
		  '/setrc'            => \&resp_setrc,
		  '/test_info'        => \&resp_test_info,
		  '/whitelist_info'   => \&resp_whitelist_info,
		  '/svnlog'           => \&resp_svnlog,
		  '/latest_good'      => \&resp_latest_good,
		  '/qstat_job'        => \&resp_qstat_job,
		  '/qdel_job'         => \&resp_qdel_job,
		  '/'                 => \&resp_latest);
  

  # Generic request dispatcher
  sub handle_request {
    my $self = shift;
    my $cgi  = shift;
    
    my $path = $cgi->path_info();
    my $handler = $dispatch{$path};
    
    if (ref($handler) eq "CODE") {
      print "HTTP/1.0 200 OK\r\n";
      $handler->($cgi);
    } else {
      print "HTTP/1.0 404 Not found\r\n";
      print $cgi->header,
      $cgi->start_html('Not found'),
      $cgi->h1('Not found'),
      $cgi->end_html;
    }
  }
  

  sub redirect {
    my ($cgi, $url) = @_;
    print $cgi->header, $cgi->start_html(
	-head => ["<meta http-equiv=\"refresh\" content=\"0;url=$url\">"] );
    print $cgi->end_html;    
  }


  # Print out information about the whitelist
  sub resp_whitelist_info {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;

    print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});

    print "<H1>Errors</H1>\n";
    foreach my $word (@cbs_config::error_words) { print "$word<BR>\n"; }
    print "<H1>Errors Whitelist</H1>\n";
    foreach my $word (@cbs_config::error_whitelist) { print "$word<BR>\n"; }    
    print "<H1>Warnings</H1>\n";
    foreach my $word (@cbs_config::warning_words) { print "$word<BR>\n"; }
    print "<H1>Warnings Whitelist</H1>\n";
    foreach my $word (@cbs_config::warning_whitelist) { print "$word<BR>\n"; }
    print "<H1>SFDS silent errors</H1>\n";
    foreach my $word (@cbs_config::sfds_silent_errors) { print "$word<BR>\n"; }
    print "<H1>SFDS errors</H1>\n";
    foreach my $word (@cbs_config::sfds_errors) { print "$word<BR>\n"; }
    print "<H1>SFDS errors notify</H1>\n";
    foreach my $word (@cbs_config::sfds_errors_notify) { print "$word<BR>\n"; }

    print $cgi->end_html;
  }


  # Print out information about a test (link from the column heading)
  sub resp_test_info {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $test = $cgi->param('test');

    print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});

    my $extra = "";
    if ($test=~/^smoke_/) {
      $extra = " $test";
      $test = "smoke";
    }

    if ($test && $cbs_config::test_target{$test}) {
      foreach my $key (keys(%{$cbs_config::test_target{$test}})) {
	print "<B>$key</B>: ".$cbs_config::test_target{$test}{$key}."<BR>\n";
      }
      print "<H1>To replicate $test</H1>\n";
      print "cd ".$cbs_config::svnmod."/".$cbs_config::test_target{$test}{'dir'}."<BR>\n";
      print $cbs_config::test_target{$test}{'trgt'}."$extra<BR>\n";
      
    } else {
      print "Unknown test '$test'";
    }

    print $cgi->end_html;    
  }


  # Force the return code for a test
  sub resp_setrc {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $rev = $cgi->param('rev');
    my $id = $cgi->param('id');
    my $rc = $cgi->param('rc');

    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $retest = $dbh->prepare("UPDATE tests SET start_compile=?, end_compile=?, rc=? WHERE id=?") or die;
    my $now = time();
    $retest->execute($now, $now, $rc, $id) or die;

    if ($rc eq "0") {
      my $seterrs = $dbh->prepare("UPDATE tests SET n_errors=?, n_warnings=? WHERE id=?") or die;
      $seterrs->execute(0, 0, $id) or die;
    }

    redirect($cgi, "/?max_checkinid=$rev&num_rows=1");
  }
  

  sub resp_retest {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $rev = $cgi->param('rev');
    my $test = $cgi->param('test');

    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $extra = $test ? "AND testtype='$test'" : "";
    my $retest = $dbh->prepare("UPDATE tests SET rc=$cbs_config::rc_resched WHERE checkin='$rev' $extra") or die;
    $retest->execute() or die;

    redirect($cgi, "/?max_checkinid=$rev&num_rows=1");
  }


  sub print_top_target {
    my ($url,$text) = @_;
    print "[<A HREF=\"$url\" target=\"_top\">$text</A>]&nbsp;\n";
  }


  sub resp_log {
     my $cgi  = shift;   # CGI.pm object
     return if !ref $cgi;
     my $rev = $cgi->param('rev');
     my $test= $cgi->param('test');
     my $add= $cgi->param('add') ? $cgi->param('add') : "";
     my $id = $cgi->param('id');

     my $file = cbs_common::log_rev_test_filename($rev,$test).$add;

     print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});


     print_top_target("/", "Home");
     print_top_target("/retest?rev=$rev&test=$test", "Retest");
     print_top_target("/retest?rev=$rev", "Retest revision");
     print_top_target("/setrc?id=$id&rev=$rev&rc=0", "Set as pass");
     print_top_target("/setrc?id=$id&rev=$rev&rc=$cbs_config::rc_forcedfail", "Set as fail");
     print_top_target("/setrc?id=$id&rev=$rev&rc=$cbs_config::rc_forcedunknown", "Unknown fail");

     my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
     my ($machine, $start, $end, $rc, $n_errors, $n_warnings, $testtype, $checkin) = 
       $dbh->selectrow_array("SELECT machine, start_compile, end_compile, rc, n_errors, n_warnings, testtype, checkin FROM tests WHERE id=$id",{RaiseError=>1});

     if ($rc == 0) {
       print_top_target("/setrc?id=$id&rev=$rev&rc=$cbs_config::rc_reparse", "Reparse log");
     }

     print "<BR>Machine: $machine";
     print "<BR>Testtype: $testtype";
     print "<BR>SVN revision: $checkin";

     my ($coverage) = $dbh->selectrow_array("SELECT coverage FROM checkins WHERE id=$rev");

     my $cmd_out;
     if ($testtype=~/^special/) {
       my ($dir, $cmd, $extra, $timeout, $backdep, $simlist) = 
	 $dbh->selectrow_array("SELECT dir, cmd, extra, timeout, backdep, simlist"
			       ." FROM special_tests WHERE testid=$id",{RaiseError=>1});
       print "<BR>Dir: $dir";
       $cmd_out = cbs_common::fix_up_runsim_cfg($cmd, $extra);
       print "<BR>Backdep: $backdep";
       print "<BR>Simlist: $simlist";
       print "<BR>Timeout allowed: $timeout secs ";
     } else {
       print "<BR>Dir: ",$cbs_config::test_target{$testtype}{'dir'};
       $cmd_out = $cbs_config::test_target{$testtype}{'trgt'};
     }
     if ($coverage) {
       $cmd_out=~s/runsim/runsim -cm/;
     }
     print "<BR>Cmd: ",$cmd_out;
     
     print POSIX::strftime("<BR>Starttime: %c",localtime($start));
     if ($end) {
       print POSIX::strftime("<BR>Endtime:   %c",localtime($end));
     } else {
       print "<BR>Endtime: Still running";
     }
     print POSIX::strftime("<BR>Testtime:  %T",gmtime($end-$start));
     print "<BR>rc: $rc";
     print "<BR>errors: $n_errors";
     print "<BR>warnings: $n_warnings";

     print "<HR>\n";
     print '<IFRAME ALIGN="top" HSPACE="0" VSPACE="0" frameborder="0" style="height:95%;width:100%" src="log_iframe?file='.$file.'"></IFRAME>'."\n";

     print $cgi->end_html;
  }


  sub resp_main_logs {
     my $cgi  = shift;   # CGI.pm object
     return if !ref $cgi;
     
     print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});
     
     print '[<A HREF="/">Home</A>][<A HREF="'.$cgi->self_url.'">Refresh</A>]<HR>';
     
     foreach my $log ("cbs.log","cbs_web_server.log","cbs_control.log","cbs_build.log") {

       print "Also viewable from US filespace with 'tail -f $cbs_config::mainlog/$log'\n";
       print "<IFRAME width=\"100%\" src=\"main_log?file=$log\"></IFRAME><HR>\n";
     }

     print $cgi->end_html;
  }


  sub _resp_cmd {
    my ($cgi, $cmd, $class) = @_;

    print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});
    print "<pre class=\"$class\">\n";

    print "$cmd\n";

    if (!open(CMD,"$cmd 2>&1 |")) {
      print "Error in '$cmd' was '$!'";
      print $cgi->end_html;
      return;
    }
    while(my $line=<CMD>) {
      # Need to escape certain characters from the HTML
      $line=~s/\&/&amp;/g;
      $line=~s/\</&lt;/g;
      $line=~s/\>/&gt;/g;
      print "$line";
    }
    close(CMD);

    print "</pre>\n";
    print $cgi->end_html;
  }


  # Diff from SVN - link on the +/- count
  sub resp_diff {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;

    my $rev = int($cgi->param('rev'));
    my $prev_rev = $rev -1;
    my $file = $cgi->param('file') ? $cgi->param('file') : "";
    my $display = ($file ne "") ? 0 : 1;
    my $cmd = "$cbs_config::svn diff --old=$cbs_config::repo\@$prev_rev --new=$cbs_config::repo\@$rev";
    
    print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"});
    print "<pre class=\"diff_view\">\n";

    print "$cmd\n";
    print "Matching on file '$file'";

    if (!open(CMD,"$cmd 2>&1 |")) {
      print "Error in '$cmd' was '$!'";
      print $cgi->end_html;
      return;
    }
    while(my $line=<CMD>) {
      if ("$file" ne "") {
	if ($line=~/^Index: $file$/) {
	  $display = 1;
	} elsif ($line=~/^Index/) {
	  $display = 0; 
	}
      }
      if ($display) {
	# Need to escape certain characters from the HTML
	$line=~s/\&/&amp;/g;
	$line=~s/\</&lt;/g;
	$line=~s/\>/&gt;/g;
	print "$line";
      }
    }
    close(CMD);

    print "</pre>\n";
    print $cgi->end_html;
  }


  # Log from SVN
  sub resp_svnlog {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;

    my $file = $cgi->param('file') ? $cgi->param('file') : "";
    my $cmd = "$cbs_config::svn log $cbs_config::repo/$cbs_config::svnmod/$file";
    
    _resp_cmd($cgi, $cmd, "diff_view")
  }


  # Find the latest checkin where a test is good
  sub resp_latest_good {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;

    print $cgi->header;

    if ($cgi->param('test')) {
      my $test=$cgi->param('test');
      print cbs_common::find_latest_good($test);
      print "\n";
    } else {
      print "Please specify the test parameter\n";
    }
  }


  sub output_log {
    my ($cgi, $dir, $file, $tail) = @_;

    print $cgi->header, $cgi->start_html(
	-title=>"Siena RTL Continuous Build System (CBS)",
	-style=>{'code'=>"$main::css"},
	-onLoad=>'window.scrollTo(0,document.body.scrollHeight)');
    print "<div class=\"log_view\">\n";

    my $tailcmd= ($tail!=0) ? "tail -n $tail |" : "";

    if (!$cgi->param('full_log')) {
      my $url = $cgi->self_url;
      # Don't understand why this happens yet
      $url=~s|^http://(.*?)/|/|;
      print "[<A HREF=\"$url&full_log=1\">Show full log</A>] Please wait (many regular expressions to match against the log) ....<HR>\n";
    }

    if (-f "$dir/$file") {
      open(FILE,"cat $dir/$file |$tailcmd") or die;
      print "Reading '$dir/$file' ...<BR>\n";
    } elsif (-f "$dir/$file.gz") {
      open(FILE,"zcat $dir/$file.gz |$tailcmd") or die;
      print "Reading '$dir/$file.gz' ...<BR>\n";
    } else {
      print "ERROR: Couldn't find '$dir/$file'";
      print $cgi->end_html;
      return 1;
    }

    # push out the entire file - TODO: use sendfile and send as gz
    my ($last_line, $last_err, $last_warn) = ("", "", "");
    my (@err_lines, @warn_lines);

    my @error_whitelist   = map { qr/($_)/i } @cbs_config::error_whitelist;
    my @error_words       = map { qr/($_)/i } @cbs_config::error_words;
    my @warning_whitelist = map { qr/($_)/i } @cbs_config::warning_whitelist;
    my @warning_words     = map { qr/($_)/i } @cbs_config::warning_words;

    while (my $line=<FILE>) {
      my $line2= $line;

      if ($line eq $last_line) {
	next;
      }

      # Need to escape certain characters from the HTML
      $line=~s/\&/&amp;/g;
      $line=~s/\</&lt;/g;
      $line=~s/\>/&gt;/g;

      # Highlight error and warnings - whitelists must be first as they are longer strings
      foreach my $word (@error_whitelist) {
	$line=~s/$word/<SPAN class=\"word_ignore\">$1<\/SPAN>/g;
	$line2=~s/$word//g;
      }
      my $seen_error = 0;
      foreach my $word (@error_words) {
	if ($line2=~s/$word/<SPAN class=\"word_err\">$1<\/SPAN>/g) {
	  $line=~s/$word/<SPAN class=\"word_err\">$1<\/SPAN>/g;
	  $seen_error = 1;
	}
      }
      if ($seen_error && ($last_err ne $line)) {
	push @err_lines, $line;
	$last_err = $line;
      }

      foreach my $word (@warning_whitelist) {
	$line=~s/$word/<SPAN class=\"word_ignore\">$1<\/SPAN>/g;
	$line2=~s/$word//g;
      }
      my $seen_warning = 0;
      foreach my $word (@warning_words) {
	if ($line2=~s/$word/<SPAN class=\"word_warn\">$1<\/SPAN>/g) {
	  $line=~s/$word/<SPAN class=\"word_warn\">$1<\/SPAN>/g;
	  $seen_warning = 1;
	}
      }
      if ($seen_warning && ($last_warn ne $line)) {
	push @warn_lines, $line;
	$last_warn = $line;
      }

      # Supress duplicate lines
      if ($cgi->param('full_log')) {
	print "$line<BR>\n";
      }
      $last_line = $line;
    }
    close(FILE);

    print '<HR><A HREF="/whitelist_info">Errors (repeats removed):</A><BR>';
    foreach my $err (@err_lines) {
      print "$err<BR>\n";
    }

    print '<HR><A HREF="/whitelist_info">Warnings (repeats removed):</A><BR>';
    foreach my $warn (@warn_lines) {
      print "$warn<BR>\n";
    }

    print "<HR>End of log file\n";
    print "</div>\n";
    print $cgi->end_html;  
  }


  sub resp_log_iframe {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $file = $cgi->param('file');

    output_log($cgi, $cbs_config::logdir, $file, 0);
  }


  sub resp_main_log {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $file = $cgi->param('file');

    output_log($cgi, $cbs_config::mainlog, $file, 50);
  }


  sub get_running_test {
    my ($dbh) = @_;
    my @tests = $dbh->selectrow_array("SELECT checkin FROM tests WHERE start_compile>0 AND end_compile=0",{RaiseError=>1});
    return ($tests[0]) ? $tests[0] : "idle";
  }


  # Common support function for the main IFRAME and main page display
  sub get_display_info {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;

    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $select_max_checkin = $dbh->prepare("SELECT max(id) FROM checkins") or die;

    # Get the last checkin
    $select_max_checkin->execute() || die;
    my ($last_checkinid) = $select_max_checkin->fetchrow_array();
    if (!$last_checkinid) { $last_checkinid = 1; }

    # Get the number of rows
    my $num_rows = $cgi->param('num_rows');
    if (!$num_rows) {
      $num_rows=16;
    }

    # Get the max and min checkinid to process
    my $max_checkinid = $cgi->param('max_checkinid');
    if (!$max_checkinid) {
      $max_checkinid = $last_checkinid;
    }
    my $min_checkinid = $max_checkinid - $num_rows + 1;
    if ($min_checkinid < 1) {
      $min_checkinid = 1;
    }

    my $running_test = get_running_test($dbh);
    return ($min_checkinid, $max_checkinid, $num_rows, $last_checkinid, $running_test);
  }


  sub resp_latest {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $frame = $cgi->param('frame') || "main_iframe";
    my $refresh = $cgi->param('refresh') || 30;

    if ($refresh!=-1) {
      print $cgi->header, $cgi->start_html(-title=>"Siena RTL Continuous Build System (CBS)",
					   -style=>{'code'=>"$main::css"},
					   -head => ["<meta http-equiv=\"refresh\" content=\"$refresh\">"]);
    } else {
      print $cgi->header, $cgi->start_html(-title=>"Siena RTL Continuous Build System (CBS)",
					   -style=>{'code'=>"$main::css"});
    }

    print_nav(get_display_info($cgi), $cgi->param('onlyspecial'));
    print_latest_regression();
    print_motd();

    print '<IFRAME HSPACE="0" VSPACE="0" name="mainiframe" frameborder="0" style="height:85%;width:100%;vertical-align:bottom;float:left;" src="/'
      .$frame.$cgi->url(-absolute=>1, -query=>1).'"></IFRAME>'."\n";
    
    print $cgi->end_html;
  }


  sub print_id_author_time_size {
    my ($cid, $author, $date, $size) = @_;
    # Id, author
    print "<TD VALIGN=top><A HREF=\"/diff?rev=$cid\" TARGET=\"_top\">$cid</A></TD>\n";
    print "<TD VALIGN=top>$author</TD>\n";
    # Time - expanded if older than 1 week
    print "<TD VALIGN=top>";
    if ($date > time() - 60*60*24*7) {
      print POSIX::strftime("%a %T",localtime($date));
    } else {
      print POSIX::strftime("%c",localtime($date));
    }
    print "</TD>\n";      
    # Print the work space size
    if ($size) {
      printf "<TD>%dMb</TD>\n", $size/1024;
    } else {
      print "<TD>?</TD>\n";
    }
  }


  sub print_comments_filelist {
    my ($even, $cid, $comment, $files, $diffs) = @_;
    
    print "<TR class=", $even ? '"even_row"' : '"odd_row"', ">\n";
    # Need to escape certain characters from the HTML
    $comment=~s/\&/&amp;/g;
    $comment=~s/\</&lt;/g;
    $comment=~s/\>/&gt;/g;
    $comment=~s/\n/<BR>\n/g;
    print "<TD VALIGN=top COLSPAN=4>$comment</TD>\n";
    print "</TR>\n";
    
    # Print the file list and +/- list
    print "<TR class=", $even ? '"even_row"' : '"odd_row"', ">\n";
    $files=~s#^lom/##mg;
    my @filesa = split(/\n/, $files);
    my @diffsa = split(/\n/, $diffs);
    $files=~s/\n/<BR>\n/g;
    $diffs=~s/\n/<BR>\n/g;
    
    if (scalar(@filesa) && (scalar(@filesa)==scalar(@diffsa))) {
      # File list
      print "<TD COLSPAN=3 VALIGN=top class=\"file_list\">\n";
      for (my $i=0 ; $i<scalar(@filesa) ; $i++ ) {
	my $filename = "$filesa[$i]";
	print "<A HREF=\"/svnlog?file=$filename\" target=\"_top\">H</A>|";
	print "<A HREF=\"http://ocsync01/svn/repo_SFL9021AA/SFL9021AA/lom/$filename\" target=\"_top\">L</A> $filename<BR>\n";
      }
      print "</TD>\n";
      # +/- list
      print "<TD VALIGN=top class=\"diff_list\">\n";
      for (my $i=0 ; $i<scalar(@filesa) ; $i++ ) {
	my $diff = $diffsa[$i];
	my $file = $filesa[$i];
	print "<A HREF=\"/diff?rev=$cid&file=lom/$file\" TARGET=\"_top\">$diff</A><BR>\n";
      }
      print "</TD>\n";
      
    } else {
      # If they do not tally
      print "<TD VALIGN=top class=\"file_list\">$files</TD>\n";
      print "<TD>?</TD>\n";
    }
  }
  

  sub rc_is_bad {
    my ($rc) = @_;
    return ($rc!=110 && $rc<256) ||
      ($rc==$cbs_config::rc_parsefail) ||
      ($rc==$cbs_config::rc_forcedfail) ||
      ($rc==$cbs_config::rc_smokefail);
  }

  
  sub get_state {
    my ($rc, $start_compile, $end_compile) = @_;
    if ($rc == $cbs_config::rc_resched)       { return "Rep"; }
    if ($rc == $cbs_config::rc_pendgrid)      { return "Pen"; } 
    if ($start_compile!=0 && $end_compile==0) { return "RUN"; }
    if ($rc == $cbs_config::rc_newtest)       { return "NEW"; }
    if ($rc == $cbs_config::rc_unnecessary)   { return "NA"; }
    return "";
  }


  sub result_cell {
    my ($rowspan, $test, $cid, $id, $rc, $start_compile, $end_compile, $n_errs, $n_warns, $withbr) = @_;

    my ($errwarn, $special, $class) = ("","","","");
    my $logname = "log?id=$id&rev=$cid&test=$test&add=";
    my $state = get_state($rc, $start_compile, $end_compile);
    my $br = $withbr ? "<BR>" : " ";

    if ($start_compile==0) { $start_compile=time(); }
    if ($end_compile==0)   { $end_compile=time(); }
    
    if ($end_compile != 0) {
      $errwarn = "E$n_errs$br W$n_warns";
    }

    if ($state eq "OK") {
      if ($test=~/^lint/) {
	$special = "$br<A HREF=\"$logname".".moresimple.rpt\" target=\"_top\" >lint rpt</A>";
      }
    }
    if ($rc==0 && $n_errs==0) {
      $class = "good_test";
    } elsif (rc_is_bad($rc)) {
      $class = "bad_test";
    } elsif ($state eq "RUN") {
      $class = "run_test";
    } elsif ($rc==$cbs_config::rc_resched) {
      $class = "";
    } elsif ($rc==$cbs_config::rc_newtest) {
      $class = "";
    } elsif ($rc==$cbs_config::rc_pendgrid) {
      $class = "";
    } elsif ($rc==$cbs_config::rc_unnecessary) {
      $class = "";
    } else {
      $class = "unknown_test";
    }
    
    if ($class ne "") {
      print "<TD rowspan=$rowspan class=\"$class\">";
    } else {
      print "<TD rowspan=$rowspan>";
    }
    print "<A HREF=\"$logname\" target=\"_top\">$state$br$errwarn\</A>$special$br";
    my ($tsec,$tmin,$thour,) = gmtime($end_compile-$start_compile);
    if ($thour) {
      printf "%d:%2.2d:%2.2d",$thour,$tmin,$tsec;
    } elsif ($tmin) {
      printf "%d:%2.2d",$tmin,$tsec;
    } else {
      printf ":%2.2d",$tsec;
    }
    print "</TD>";
  }

  ##############################################################################

  sub stat_row_time {
    my ($nempty, $stat, $stats, @revs) = @_;

    print "<TR>\n";
    print "<TD></TD>" x $nempty;
    print "<TD>".uc($stat)."</TD>\n";

    foreach my $rev (@revs) {
       my ($tsec,$tmin,$thour,$tday,) = gmtime($stats->{$rev}{$stat});
       $thour += ($tday-1)*24;
      printf("<TD>%d:%2.2d</TD>", $thour, $tmin);
    }
    print "</TR>\n";
  }


  sub stat_row_counter {
    my ($nempty, $stat, $stats, @revs) = @_;

    print "<TR>\n";
    print "<TD></TD>" x $nempty;
    print "<TD>".uc($stat)."</TD>\n";

    foreach my $rev (@revs) {
      printf("<TD>%d</TD>", $stats->{$rev}{$stat});
    }
    print "</TR>\n";
  }


  sub stat_row_percent {
    my ($nempty, $stat, $stats, @revs) = @_;

    print "<TR>\n";
    print "<TD></TD>" x $nempty;
    print "<TD>".uc($stat)."</TD>\n";

    foreach my $rev (@revs) {
      my $total = $stats->{$rev}{'total'};
      if ($total) {
	printf("<TD>%d (%d%%)</TD>", $stats->{$rev}{$stat}, int(0.5+100.0*$stats->{$rev}{$stat} / $total));
      } else {
	print "<TD>0</TD>\n";
      }
    }
    print "</TR>\n";
  }


  sub special_one_headings {
    my ($days, @col_names) = @_;

    print "<TR>";
    if ($days>1) {
      print "<TH>Platform</TH>\n";
    }
    print "<TH>Simlist</TH>\n";
    print "<TH>Cmd</TH>\n";
    foreach my $colname (@col_names) {
      $colname=~s/[._]/ /g;
      $colname=~s/-cfg/<BR>-cfg/;
      print "<TH>$colname</TH>\n";
    }
    if ($days==1) {
      print "<TH>Comments</TH>\n";
    }
    print "</TR>\n";
  }


  sub special_col_name {
    my ($days, $rev, $dir, $extra) = @_;

    if ($days>1) {
      return "$rev";
    } else {
      $dir=~s|^dv/sim/||;
      #$extra=~s|-cfg||;
      #$extra=~s|\s||g;
      #if ($extra ne "") { $extra="_$extra"; }
      return "$dir $extra";
    }
  }


  sub special_row_name {
    my ($days,$simlist, $cmd, $dir) = @_;
    if ($days>1) {
      return "$simlist $dir $cmd";
    } else {
      return "$simlist $cmd";
    }
  }


  # Page for a comparison of special tests within a revision
  sub resp_special_iframe {
    my $cgi  = shift;   # CGI.pm object
    my (%stats, %results);
    return if !ref $cgi;

    print $cgi->header, $cgi->start_html(-style=>{'code'=>"$main::css"},-title=>"CBS regression results");
    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $rev = $cgi->param('rev');
    my $days = $cgi->param('days') ? $cgi->param('days') : 1;

    # Process extra filtering parameters
    my $platform_filter = $cgi->param('platform');
    my $platform_not_filter = $cgi->param('platform_not');
    my $cfg_filter = $cgi->param('cfg');
    my $cfg_not_filter = $cgi->param('cfg_not');
    my $filter = "";
    if ($platform_filter) {
      $filter.=" AND special_tests.dir LIKE '%$platform_filter%'";
    }
    if ($platform_not_filter) {
      $filter.=" AND NOT ( special_tests.dir LIKE '%$platform_not_filter%' )";
    }
    if ($cfg_filter) {
      $filter.=" AND special_tests.extra LIKE '%$cfg_filter%'";
    }
    if ($cfg_not_filter) {
      $filter.=" AND NOT ( special_tests.extra LIKE '%$cfg_not_filter%' )";
    }

    # NB GROUP BY must match the next SELECT (for data extraction)
    my ($get_cols);
    if ($days>1) {
      $get_cols = $dbh->prepare("SELECT id, coverage  FROM checkins WHERE regression=1 AND id<=? ORDER BY id DESC LIMIT $days") || die("$!");
    } else {
      $get_cols = $dbh->prepare("SELECT checkin,dir,extra FROM special_tests WHERE checkin=? $filter GROUP BY dir, extra") || die("$!");
    }
    $get_cols->execute($rev) || die("$!");

    print "<TABLE>\n";

    # Print headings
    my ($min_rev, $max_rev, @col_names, @col_names_display, @stats);
    while (my ($rev, $dir, $extra) = $get_cols->fetchrow_array()) {
      $min_rev = (!$min_rev || ($rev < $min_rev)) ? $rev : $min_rev;
      $max_rev = (!$max_rev || ($rev > $max_rev)) ? $rev : $max_rev;
      my $index = scalar(@col_names);
      $stats{$index}={'running'=>0, 'good'=>0, 'timeout'=>0, 'bad'=>0, 'timeout'=>0, 'unknown'=>0, 'runtime'=>0};
      push @col_names, special_col_name($days, $rev, $dir, $extra);
      if ($days>1 && $dir==1) {
	push @col_names_display, special_col_name($days, "$rev-cm", "", "");
      } else {
	push @col_names_display, special_col_name($days, $rev, $dir, $extra);
      }
    }
    # Reverse because of the way that DESC LIMIT is used in the SQL
    if ($days>1) {
      @col_names         = reverse @col_names;
      @col_names_display = reverse @col_names_display;
    }
    special_one_headings($days, @col_names_display);

    # Start of main data grid
    print "<TR>";
    my $col_index = 0;
    my $first = 1;
    my $row_count = 0;

    # Read in all the comments
    my %comments;
    if ($days==1) {
      my $sql = "SELECT comments.cmd, comment FROM comments, special_tests WHERE comments.cmd=special_tests.cmd AND checkin=?";
      my $select_comments = $dbh->prepare($sql) || die("$!");
      $select_comments->execute($rev) || die("$!");
      while (my ($cmd, $comment) = $select_comments->fetchrow_array()) {
	$comments{$cmd} = $comment;
      }
    }

    # NB ORDER BY must match the previous SELECT (for column headings)
    my $sql = "SELECT special_tests.checkin, dir, cmd, simlist, extra, author, tests.id, testtype, rc, ".
      "n_errors, n_warnings, start_compile, end_compile ".
      "FROM tests, special_tests ".
      "WHERE tests.id=special_tests.testid AND special_tests.checkin>=? AND special_tests.checkin<=? AND testtype LIKE 'special_%' $filter ";
    $sql.="ORDER BY simlist, cmd, dir, extra, special_tests.checkin";
    my $select_special = $dbh->prepare($sql) || die("$!");
    $select_special->execute($min_rev, $max_rev) || die("$!");

    my $row_name="";
    while (my ($svnrev, $dir, $cmd, $simlist, $extra, $author, $id, $testtype, $rc, $n_errs, $n_warns, $start_compile, $end_compile) = 
	   $select_special->fetchrow_array()) {
      
      # Find a place to slot in the result
      while ($first ||
	     ($col_index >= scalar(@col_names)) ||
	     (special_col_name($days, $svnrev, $dir, $extra) ne $col_names[$col_index]) ||
	     (special_row_name($days, $simlist, $cmd, $dir) ne $row_name)
	     ) {

	$col_index++;

	# New row creation
	if ($first || ($col_index > scalar(@col_names))) {
	  if (!$first) {
	    # end the row with the comment form
	    if ($days==1) {
	      print "<TD>";
	      my $comment = $comments{$cmd} ? $comments{$cmd} : "";
	      print '<form name="input" action="/update_comment" method="get">';
	      print '<input type="text" name="comment" value="',$comment,'">';
	      print '<input type="hidden" name="cmd" value="'.CGI::escapeHTML($cmd).'">';
	      print "<input type=\"hidden\" name=\"rev\" value=\"$svnrev\">";
	      print "<input type=\"hidden\" name=\"days\" value=\"$days\">";
	      print '<input type="submit" value="+"></form></TD>';
	    }

	    print "</TR>";
	    $row_count++;
	    if (($row_count % 25) == 0) {
	      special_one_headings($days, @col_names_display)
	    }
	  }

	  # Fill in the initial colums
	  print "<TR class=", ($row_count % 2) ? '"even_row"' : '"odd_row"', ">\n";
	  my ($shortcmd) = ($cmd=~/-t (.*)/);
	  
	  if ($days>1) {
	    my $platform = basename($dir);
	    print "<TD>$platform</TD>";
	  };
	  print "<TD>$simlist</TD>";
	  if ($days>1) {
	    my ($cmdlink) = ($shortcmd=~/\s*(\w+)/);
	    print "<TD><A HREF=\"http://autodocs.uk.solarflarecom.com/doc/html_tbsienaa0/testcase-$cmdlink.html\">$shortcmd $extra</A></TD>\n";
	  } else {
	    print "<TD>$shortcmd $extra</TD>\n";
	  }

	  $row_name=special_row_name($days, $simlist, $cmd, $dir);
	  $col_index=0;
	} elsif (!$first) {
	  # Unknown
	  print "<TD>-</TD>";
	}
	$first=0;
      }
      result_cell(1, $testtype, int($svnrev), int($id), int($rc), int($start_compile), int($end_compile), int($n_errs), int($n_warns), 0);

      $stats{$col_index}{'total'}++;
      if ($start_compile && $rc!=$cbs_config::rc_pendgrid) {
	my $end_or_now = $end_compile ? $end_compile : time();
	$stats{$col_index}{'runtime'}+=($end_or_now-$start_compile);
      }
      if ($start_compile>0 && $end_compile==0 && $rc!=$cbs_config::rc_pendgrid) {
	$stats{$col_index}{'running'}++;
      }
      if ($rc==0 && $n_errs==0)                { $stats{$col_index}{'good'}++;    }
      elsif ($rc==110)                         { $stats{$col_index}{'timeout'}++; }
      elsif (rc_is_bad($rc))                   { $stats{$col_index}{'bad'}++;     }
      else                                     { $stats{$col_index}{'unknown'}++; $stats{$col_index}{'total'}--; }
      $col_index++;
    }
    print "</TR>";
    special_one_headings($days, @col_names_display);
    
    my @revs = sort(keys(%stats));
    my $num_cells = ($days==1) ? 1 : 2;
    stat_row_counter($num_cells, 'running', \%stats, @revs);
    stat_row_percent($num_cells, 'good',    \%stats, @revs);
    stat_row_percent($num_cells, 'bad',     \%stats, @revs);
    stat_row_percent($num_cells, 'timeout', \%stats, @revs);
    stat_row_counter($num_cells, 'total',   \%stats, @revs);
    stat_row_counter($num_cells, 'unknown', \%stats, @revs);
    stat_row_time($num_cells, 'runtime',    \%stats, @revs);
    print "</TABLE>\n";

    print $cgi->end_html;
  }


  
  sub resp_update_comment {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $rev = $cgi->param('rev');
    my $comment = $cgi->param('comment');
    my $cmd = $cgi->param('cmd');
    my $days = $cgi->param('days') ? $cgi->param('days') : 1;

    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $sql =  $dbh->prepare("REPLACE INTO comments VALUES (NULL, ?, ?);");
    $sql->execute($cmd, $comment) || die("$!");

    redirect($cgi, "/special_iframe?rev=$rev&days=$days");
  }

  ##############################################################################

  # From running jobs page
  sub resp_qdel_job {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $id    = $cgi->param('id');
    my $jobid = $cgi->param('jobid');
    
    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $sql = $dbh->prepare("UPDATE tests SET rc=$cbs_config::rc_resched WHERE id=?");
    $sql->execute($id) || die("$!");

    print $cgi->header;
    open(CBS, "$cbs_config::qdel $jobid 2>&1 |") || die;
    print "<pre>";
    while (my $line=<CBS>) {
      chop $line;
      print "$line<BR>\n";
    }
    print "</pre>";
    close(CBS);

    print $cgi->end_html;
  }


  # From running jobs page
  sub resp_qstat_job {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $id    = $cgi->param('id');
    my $jobid = $cgi->param('jobid');
    
    print $cgi->header;
    open(CBS, "$cbs_config::qstat -j $jobid 2>&1 |") || die;
    print "<pre>";
    while (my $line=<CBS>) {
      chop $line;
      print "$line<BR>\n";
    }
    print "</pre>";
    close(CBS);

    print $cgi->end_html;
  }


  # Show the latest tests that have finished/still running
  sub resp_recentend_iframe {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $num = $cgi->param('num') || 64;
    my $running = $cgi->param('running');
    my $even = 1;

    print $cgi->header, $cgi->start_html(-style=>{'code'=>"$main::css"});
    print "<H1>",$running ? "Running" : "Recently ended"," tests</H1>\n";

    # Make the database connections
    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");

    my $sql = "SELECT id,checkin,testtype,start_compile,end_compile,rc,n_errors,n_warnings,machine,jobid FROM tests ";
    if ($running) {
      $sql.="WHERE end_compile=0 AND start_compile!=0 ORDER BY id";
    } else {
      $sql.="WHERE end_compile!=0 AND start_compile!=0 ORDER BY end_compile DESC LIMIT $num";
    }
    
    my $select_tests = $dbh->prepare($sql) or die("$!");
    $select_tests->execute() or die("$!");
    
    print "<TABLE><TR><TH>Testtype</TH><TH>Endtime</TH><TH>Machine</TH><TH>Result</TH><TD>JobID</TD></TR>\n";
    while (my ($id, $checkin, $testtype, $start_compile, $end_compile, $rc, $n_errs, $n_warns, $machine, $jobid) = 
	   $select_tests->fetchrow_array()) {
      print "<TR class=", $even ? '"even_row"' : '"odd_row"', "><TD>$testtype</TD>\n";
      print POSIX::strftime("<TD>%T</TD>",localtime($end_compile));
      print "<TD>$machine</TD>";
      result_cell(1, $testtype, int($checkin), int($id), int($rc), int($start_compile), int($end_compile), int($n_errs), int($n_warns), 0);
      if ($running) {
	print "<TD><A HREF=\"/qdel_job?id=$id&jobid=$jobid\">Kill job $jobid</A> ";
	print "<A HREF=\"/qstat_job?id=$id&jobid=$jobid\">Info on $jobid</A></TD>";
      } else {
	print "<TD>$jobid</TD>";
      }
      print "</TR>\n";
      $even=!$even;
    }
    print "</TABLE?\n";
  }

  ##############################################################################

  # Main page in grid format
  sub resp_main_iframe {
    my $cgi  = shift;   # CGI.pm object
    my $even = 1;
    return if !ref $cgi;
    
    print $cgi->header, $cgi->start_html(-style=>{'code'=>"$main::css"});

    # Make the database connections
    my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
    my $select_tests = $dbh->prepare("SELECT id,checkin,testtype,start_compile,end_compile,rc,n_errors,n_warnings FROM tests WHERE checkin>=? and checkin<=?") or die;
    my $select_checkins = $dbh->prepare("SELECT id,author,comment,files,diffs,date,size,regression FROM checkins WHERE id>=? and id<=? ORDER BY id DESC") or die;
    
    # Collect result info - use associative arrays to cope with any missing results
    my (%id, %rc, %start_compile, %end_compile, %n_errs, %n_warns, %tests_per_checkin, $max_tests_per_checkin, %testhash);
    $max_tests_per_checkin = 0;
    my ($min_checkinid, $max_checkinid, ) = get_display_info($cgi);

    $select_tests->execute($min_checkinid, $max_checkinid) or die;
    

    while (my ($id_, $checkin, $testtype, $start_compile_, $end_compile_, $rc_, $n_errs_, $n_warns_) = $select_tests->fetchrow_array()) {
      my $key;
      
      # No point displaying these
      if ($cbs_config::test_target{"$testtype"} && $cbs_config::test_target{"$testtype"}{"nowebdisplay"}) {
	next;
      }

      if (!$tests_per_checkin{"$checkin"}) {
	@{$tests_per_checkin{"$checkin"}} = ();
      }
      my ($specialid) = ($testtype=~/special_/);

      if ($cgi->param('onlyspecial')) {
	$specialid || next;
	if (scalar(@{$tests_per_checkin{"$checkin"}}) > $max_tests_per_checkin) {
	  $max_tests_per_checkin++;
	}
      } else {
	$specialid && next;
      }
      push @{$tests_per_checkin{"$checkin"}}, $testtype;

      $key = "$checkin\_$testtype";
      $testhash{"$testtype"} = 1;
      $id{"$key"} = $id_;
      $rc{"$key"} = $rc_;
      $start_compile{"$key"} = int($start_compile_);
      $end_compile{"$key"} = int($end_compile_);
      $n_errs{"$key"} = int($n_errs_);
      $n_warns{"$key"} = int($n_warns_);
    }
    my @tests = sort { lc($a) cmp lc($b) } keys(%testhash);

    print '<TABLE width="100%">'."\n";
    
    # Headers
    print "<TR>";
    print "<TH>Id / Comments / Files</TH>\n";
    print "<TH>Author</TH>\n";
    print "<TH>Time</TH>\n";
    print "<TH>Size / +/-</TH>\n";
    
    # Print column headings
    if ($cgi->param('onlyspecial')) {
      for (my $i = 0; $i < $max_tests_per_checkin ; $i++) {
	print "<TH>$i</TH>";
      }
    } else {
      foreach my $test (@tests) {
	if ($test eq "get_size") {
	  next;
	}

	my $test2 = $test;
	if ($cbs_config::test_target{"$test"} && $cbs_config::test_target{"$test"}{'shortname'}) {
	  $test2=$cbs_config::test_target{"$test"}{'shortname'};
	} else {
	  $test2=~s/_/ /g; # so columns can be split
	  $test2=~s/smoke/smk/g;
	}
	print "<TH class=\"header\"><A HREF=\"/test_info?test=$test\"\>$test2</A></TH>";
      }
    }
    print "</TR>\n";
    
    # Get all data - don't keep a reader lock on the DB while displaying
    $select_checkins->execute($min_checkinid, $max_checkinid) or die;
    my $checkins_ary_ref = $select_checkins->fetchall_arrayref();

    # Print the data matrix
    foreach my $row  (@$checkins_ary_ref) {
      my ($cid,$author,$comment,$files,$diffs,$date,$size, $regression) = @$row;
      if ($regression) {
	my $colspan=scalar(@tests) + 4;
	print "<TR><TD colspan=$colspan class=\"regression\">";
	print_regression_banner($cid);
	print "<TD></TR>\n";
      }

      print "<TR class=", $even ? '"even_row"' : '"odd_row"', ">\n";

      # Print general info
      print_id_author_time_size($cid, $author, $date, $size);

      # Display test results with sparsely populated grid (or not for specials)
      foreach my $test (@tests) {
	my $it = "$cid\_$test";

	# No point displaying this
	if ($test eq "get_size") { next; }

	if (!exists($end_compile{"$it"})) {
	  print "<TD rowspan=3>?</TD>";
	} else {
	  result_cell(3, $test, $cid, $id{"$it"}, $rc{"$it"}, $start_compile{"$it"}, $end_compile{"$it"},
		      $n_errs{"$it"}, $n_warns{"$it"}, 1);
	}
      }
      print "</TR>\n";

      # Print the rest of checkin info
      print_comments_filelist($even, $cid, $comment, $files, $diffs);
      
      $even=!$even;
    }
    print "</TABLE>\n";
    
    # Footer
    print $cgi->end_html;
  }
  

  sub print_regression_banner {
    my ($rev) = @_;
    my $link     = "special_iframe?rev=$rev&days=6";
    my $link_one = "special_iframe?rev=$rev";
    
    print "<SPAN class=\"regression_text\">";
    print "Latest regression result available for SVN ID $rev";
    print "<A HREF=\"$link_one\" class=\"regression_text\" target=\"_top\">[one day]</A>";
    print "<A HREF=\"$link\"     class=\"regression_text\" target=\"_top\">[many days]</A>";
    print "</SPAN>";
  }


  sub print_latest_regression {
    print "<DIV style=\"width:100%\" class=\"regression\">";
    my $rid = cbs_common::latest_regress_svnid();
    print_regression_banner($rid);
    print "</DIV>\n";    
  }


  sub print_motd {
    print "<HR><DIV>$cbs_config::motd</DIV><HR>\n";
  }


  sub print_nav {
    my ($min_checkinid, $max_checkinid, $num_rows, $last_checkinid, $running_test, $onlyspecial) = @_;

    if ($cbs_config::release ne "running") {
      print "<H1>$cbs_config::release release</H1>\n";
    }

    print '<P width="100%">';
    # Left
    print '<DIV style="float: left">';
    print '<A HREF="/" target="_top">[Home]</A>';
    if ($max_checkinid < $last_checkinid) {
      print '<A HREF="/" target="_top">[Latest]</A>';
      print "<A HREF=\"?max_checkinid=",$max_checkinid+$num_rows,"\">[Newer]</A>\n";
    } else {
      print "[Latest] [Newer]\n";
    }
    print "<A HREF=\"?max_checkinid=",$max_checkinid,"&num_rows=",$num_rows,"&refresh=-1\">[Permalink]</A>\n";
    if ($min_checkinid > 1) {
      print "<A HREF=\"?max_checkinid=",$min_checkinid-1,"\">[Older]</A>\n";
    }
    print '</DIV>';

    # Right
    print '<DIV style="float: right">';
    print '<A HREF="mailto:rstonehouse@solarflare.com">[Help]</A>'."\n";
    print '<A HREF ="http://intranet.uk.solarflarecom.com/staffwiki/SienaContinuousBuildSystem">[Wiki]</A>'."\n";
    print '<A HREF ="/whitelist_info">[Whitelist]</A>'."\n";
    my $hostname = `hostname --fqdn`;
    chop $hostname;
    print "<A HREF=\"http://$hostname:1617/control\">[Control]</A>\n";
    print "</DIV>";
    
    # Middle
    print '<DIV style="text-align: center">[cbs version $Rev: 8345 $][page update ';
    my @ltime=localtime();
    print POSIX::strftime("%T",@ltime);
    print '[<A HREF="/latest?frame=recentend_iframe&running=1" target="_top">'.$running_test.'</A>]';
    print '[<A HREF="/latest?frame=recentend_iframe" target="_top">ended</A>]';
    print '[<A HREF="/main_logs">logs</A>][latest SVN is ';
    print cbs_common::latest_db_svnid(),']</DIV>';

    print "</P>";
  }
}

# Inline style sheet (CSS)
$main::css=<<"END";
  body {
    background-color: white;
    font-family: sans-serif;
    font-size: 75%;
  }
  .header {
    font-size: 75%;
  }
  .even_row {
    background-color: lavender;
  }
  .odd_row  {
    background-color: white;    
  }
  .regression {
    font-size: 125%;
    background-color: darkblue;
    font-weight: bold;
    text-align:center;
  }
  .regression_text {
    color: yellow;
  }
  .results {
    font-size: 125%;
    font-weight: bold;
  }
  .good_test  {
    background-color: green;
  }
  .unknown_test  {
    background-color: orange;
  }
  .bad_test  {
    background-color: red;
  }
  .run_test  {
    border-color: black;
    border-style: solid;
    border-width: medium;
  }
  .no_test {
  }
  .file_list {
    font-family: monospace;
    white-space: nowrap;
  }
  .diff_list {
    font-family: monospace;
    white-space: nowrap;
  }
  .log_view {
    font-family: monospace;
  }
  .diff_view {
    font-family: monospace;
  }
  .word_err {
    background-color: red;
  }
  .word_warn  {
    background-color: orange;
  }
  .word_ignore {
    background-color: green;
  }

  html,body { width:100%; height:100%; padding:0px; margin:0px; position:absolute; }
END

sub REAPER { };
$SIG{CHLD} = \&REAPER;

$main::pid = MyWebServer->new($cbs_config::webport)->background();
print "Use 'kill $main::pid' to stop server.\n";

open(PID, ">$cbs_config::piddir/cbs_web_server") || die;
print PID "$main::pid\n";
close(PID);
