#!/usr/bin/perl
################################################################################
# This is part of the Siena continuous build system
# This file is the top level controler (possibly submitted to the grid)
# It runs one test and records the result
################################################################################
use strict;
use File::Basename;
use DBI;
use lib "/home/rjs/etc/perl-lib";

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));

use vars qw($argv0_is_release);
BEGIN { $argv0_is_release = 1; }
use cbs_config;
use cbs_common;

$| = 1; # autoflush

my ($dbh, $update_test_end, $update_test_rc, $update_test_start, $select_special_timeout);
my ($testid, $svnrev, $testtype, $canontype, $logdir, $logfile, $pid);

## MAIN ########################################################################
($testid, $svnrev, $testtype, $canontype) = cbs_common::common_cli_opts();
($logdir, $logfile) = cbs_common::get_log_names($svnrev, $testtype);

print "$0: Logfile at $logfile\n";
if (-f "$logfile.gz") {
  unlink("$logfile.gz") or die("$!");
}

# DB setup
$dbh = DBI->connect( "$cbs_config::dbconnect", "", "" ) or die("Could not connect to DB");
$update_test_end = $dbh->prepare('UPDATE tests SET end_compile=? WHERE id=?') || die("$!");
$update_test_rc = $dbh->prepare('UPDATE tests SET end_compile=?,rc=? WHERE id=?') || die("$!");
$update_test_start = $dbh->prepare('UPDATE tests SET start_compile=?, end_compile=0, rc=259, machine=? WHERE id=?') || die("$!");
$select_special_timeout = $dbh->prepare('SELECT timeout FROM special_tests WHERE id=?');

my $timeout = 10*60; # default

if ($testtype=~/^special_/) {
  my ($special_id) = ($testtype=~/^special_(\d+)/);
  $select_special_timeout->execute($special_id) || die("$!");
  ($timeout) = $select_special_timeout->fetchrow_array();
} else {
  $timeout = $cbs_config::test_target{$canontype}->{'timeout'};
}
($timeout) || die("Please speicfy timeout for '$canontype'");

my $host = $ENV{"HOSTNAME"};
$host=~s/\..*//;
if ($cbs_config::timeouts{$host}) {
  $timeout = $timeout * $cbs_config::timeouts{$host};
}
print "$0: '$host 'timeout is $timeout\n";


# Update running status and run the test
my $hostname = `hostname --short`;
chop $hostname;
$update_test_start->execute(time(), $hostname, $testid) || die("$!");

# Setup for the test
my $job=" $cbs_config::build $cbs_config::release $testid $svnrev $testtype";

# Run the test
my $pid = fork();
($pid >= 0) or die("Could not fork rc=$pid");

if ($pid == 0) {
  #child runs the command
  exec("$job") or die("Could not exec '$job' - $! (rc ".(0+$!).")");
  die("Should never get here");
}

# parent waits for the child to exit or the timeout
$SIG{ALRM} = sub {
  syswrite(STDERR,"Timeout($timeout) on pid=$pid. Stopping\n");
  kill("INT",$pid);
  sleep(2);
  kill("INT",-$pid);
  sleep(2);
  kill("HUP",$pid);
  sleep(2);
  kill("HUP",-$pid);
  sleep(2);
  kill("KILL",$pid);
  sleep(2);
  kill("KILL",-$pid);

  if (-f "$logfile") {
    system("/bin/gzip --force $logfile"); # Can't report if it dies
  }

  my $rc = 110;
  $update_test_rc->execute(time(), $rc, $testid) || die("$!");  
  cbs_common::sched_next_tests($testid,$svnrev,$testtype);

  exit $rc;
};
alarm($timeout);

# Wait for the child. Never completes on timeout
my $wpid = wait();
($pid == $wpid) || die("PID mistmatch $pid $wpid");
my $rc = $? >> 8;

# Actions on test completion
if ($rc==0) {
  print "Good test r$svnrev for test $testtype\n";
  cbs_common::sched_next_tests($testid, $svnrev, $testtype);
} else {
  print "Bad test r$svnrev for test $testtype\n";
  if ($cbs_config::test_target{$canontype}{'nextonerr'}) {
    cbs_common::sched_next_tests($testid, $svnrev, $testtype);
  }
};

if (-f "$logfile") {
  system("/bin/gzip --force $logfile"); # Can't report if it dies
}

# Ask the parser to look at this test there is no already a non-zero RC
if ($rc == 0) {
  $rc = $cbs_config::rc_reparse;
}

# Update the database

print "$0: Update test end $svnrev $testid $testtype $cbs_config::release rc=$rc\n";
$update_test_rc->execute(time(), $rc, $testid) || die("$!");


exit 0;
