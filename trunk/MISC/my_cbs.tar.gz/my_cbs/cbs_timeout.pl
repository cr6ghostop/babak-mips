#!/bin/env perl

# This script runs a command with a timeout
# If the timeout is reached the command is killed
# Returns the RC of the child or ETIMEDOUT

use strict;
use warnings;
$|=1;

# CLI processing
my $usage = "$0: <timeout> <cmd> [<args>]*";
scalar(@ARGV) || die("Too few arguments: $usage");
my ($timeout,@cmds) = @ARGV;

my $pid = fork();
($pid >= 0) or die("Could not fork rc=$pid");

if ($pid == 0) {
  #child runs the command
  exec("@cmds") or die("Could not exec '@cmds' - $! (rc ".(0+$!).")");
  die("Should never get here");
}

# Kill everything that was started
sub kill_all {
  kill("SIGINT",$pid);
  sleep(2);
  kill("SIGHUP",$pid);
  sleep(2);
  kill("SIGKILL",$pid);
  sleep(2);
}


# parent waits for the child to exit or the timeout
my $wrc = 0;
$SIG{ALRM} = sub {
  kill_all();
  syswrite(STDERR,"Timeout($timeout) on pid=$pid. Stopping\n");
  exit 110;
};
alarm($timeout);

my $wpid = wait();
$wrc = $? >> 8;
($wpid == $pid) || die("Unknown child process ended $pid!=$wpid");

exit $wrc;
