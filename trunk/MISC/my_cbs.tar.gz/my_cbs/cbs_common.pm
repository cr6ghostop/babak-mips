# Common routines for the Siena continuous build system (cbs)

# Robert Stonehouse
# Feb 2008

package cbs_common;

use strict;
use warnings;

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;

use vars qw($VERSION);
use POSIX qw(setsid);
$VERSION = '0.01';


sub get_log_names {
  my ($svnrev, $testtype) = @_;

  (-d "$cbs_config::logdir") or die("logdir '$cbs_config::logdir' not found");

  my $logdir = sprintf("%s/%d", $cbs_config::logdir, ($svnrev-($svnrev%100)));
  my $logfile = "$logdir/r$svnrev.$testtype";
  (-d "$logdir") || mkdir("$logdir");
  (-d "$logdir") || die;

  return ($logdir, $logfile);
}


sub kill_grid_jobs {
  system("/tools/solarflare/sfdsTools/qdel 'cbs_$cbs_config::release*'");
}


sub common_cli_opts {
  (scalar(@ARGV)==4) or die("usage: $0 <release> <testid> <svn rev> <testtype>");

  my ($release, $testid, $svnrev, $testtype) = @ARGV;
  ($release eq "running" || $release eq "testing") || die("Unknown release '$release'");

  my $canontype = $testtype;
  if ($testtype=~/^smoke_/) {
    $canontype = "smoke";
  }
  if ($testtype=~/^special_/) {
    $canontype = "special";
  }

  # NB release is not returned - access as $cbs_config::release
  return ($testid, $svnrev, $testtype, $canontype);
}


# Construct dependancies in the test hash backwards
$cbs_common::made_back_deps=0;
sub make_backwards_deps {
  if ($cbs_common::made_back_deps) {
    return;
  } else {
    $cbs_common::made_back_deps=1;
  }

  foreach my $testtype (keys(%cbs_config::test_target)) {

    # Calculate backdeps
    my $nextstring = $cbs_config::test_target{$testtype}->{'next'};
    if ($nextstring) {
      foreach my $next (split /,/,$nextstring) {
	if ($cbs_config::back_deps{$next}) {
	  $cbs_config::back_deps{$next}.=",$testtype";
	} else {
	  $cbs_config::back_deps{$next}="$testtype";
	}
      }
    }

    # Add explicit backdeps
    my $backstring = $cbs_config::test_target{$testtype}->{'backdeps'};
    if ($backstring) {
       $cbs_config::back_deps{$testtype}="$backstring";
    }
  }
}


# Return a hash of grid job IDs that are currently running and not in an error state
sub get_grid_jobs {
  my %jobs;

  # output from qstat
  # Check that jobs are not in an error state
  #    job-ID  prior   name       user         state submit/start at     queue                          slots ja-task-ID 
  #-----------------------------------------------------------------------------------------------------------------
  # 463898 0.55500 QRLOGIN    rjs          r     10/08/2008 01:56:42 dig_lnx_M16@fork.gb.solarflare     1        
  # 463901 0.45734 cbs_runnin rjs          Eqw   10/08/2008 01:58:52                                    1

  open(QSTAT, "/tools/solarflare/sfdsTools/qstat|") || die("$!");
  # Ignore the two header lines
  <QSTAT>; <QSTAT>;
  while (my $line=<QSTAT>) {
    chop $line;
    my ($id, $pri, $name, $user, $state) = ($line=~/^\s*(\d+)\s+([\d\.]+)\s+(\w+)\s+(\w+)\s+(\w+)/);
    ($id) || die("Unknown line '$line'");
    if ((($name eq "cbs_runnin") && ($cbs_config::release eq "running")) ||
	(($name eq "cbs_testin") && ($cbs_config::release eq "testing"))) {
      if ($state!~/E/) {
	$jobs{$id}=1;
      }
    }
  }
  close(QSTAT);
  return %jobs;
}


# The latest revision that the database knows about
sub latest_regress_svnid {
  # TODO pass in database handle
  my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB: $!");
  my @rows = $dbh->selectrow_array("SELECT MAX(id) FROM checkins WHERE regression=1",{RaiseError=>1});
  return $rows[0];
}


sub latest_db_svnid {
  # TODO pass in database handle
  my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB: $!");
  my @rows = $dbh->selectrow_array("SELECT MAX(id) FROM checkins",{RaiseError=>1});
  return $rows[0];
}


# Get the oldest svn revision to work on
sub get_min_checkin {
  my $min_checkin = latest_db_svnid() - $cbs_config::min_checkin;
  $min_checkin = ($min_checkin > 1) ? $min_checkin : 1;
  return $min_checkin;
}


# Use the backdep info to find the last good run for the supplied
# tests and all backwards dependancies
sub find_latest_good {
  my ($test_to_consider) =@_;
  my ($svnid) = latest_db_svnid() + 1;
  cbs_common::make_backwards_deps();

  my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB: $!");
  my $select_smoke = $dbh->prepare("SELECT id, start_compile, end_compile, rc FROM tests WHERE testtype LIKE 'smoke_%' AND checkin=?") || die("$!");
  my $select_test = $dbh->prepare("SELECT id, start_compile, end_compile, rc, n_errors FROM tests WHERE testtype=? AND checkin=?") || die("$!");

  
 FINDGOOD: 
  while ($svnid > 1) {
    $svnid--;
    my $consider=$test_to_consider;
    
    # if smoke check all the smoke tests as well - will go backwards from smoke later
    if ($consider eq "smoke") {
      $select_smoke->execute($svnid) || die("$!");
      ($select_smoke->rows==0) && next FINDGOOD;
      while (my ($id, $startcompile, $endcompile, $rc) = $select_smoke->fetchrow_array()) {
	if ($startcompile==0 || $endcompile==0 || $rc!=0) {
	  next FINDGOOD;
	}
      }
    }
    
    # Iterate through backdeps until prepare is found
    do {
      $select_test->execute($consider, $svnid) || die("$!");
      ($select_test->rows==0) && next FINDGOOD;
      while (my ($id, $startcompile, $endcompile, $rc, $n_errors) = $select_test->fetchrow_array()) {
	if (($startcompile==0) || ($endcompile==0) || ($rc!=0) || ($n_errors!=0)) {
	  next FINDGOOD;
	}
      }
      $consider = $cbs_config::back_deps{$consider};
    } while ($consider ne "prepare");
    return $svnid;
  }
    
  return "No good revision found. Sorry";
}


# Inserts a test as new (to run immediately)
sub replace_test {
  my ($svnrev, $testtype) = @_;
  my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB: $!");
  my $select_test_done = $dbh->prepare('SELECT id FROM tests WHERE checkin=? AND testtype=? AND rc!=258 AND start_compile!=0 AND end_compile!=0') || die("$!");
  my $replace_test = $dbh->prepare("INSERT INTO tests VALUES (NULL,?,?,0,0,256,0,0,'new test',0) ON DUPLICATE KEY UPDATE start_compile=0,end_compile=0,rc=256,n_errors=0,n_warnings=0,machine='new test'") || die("$!");

  $select_test_done->execute($svnrev, $testtype) || die("$!");
  if (!($select_test_done->fetchrow_array())) {
    # Avoid duplicates - use UNIQUE constraint in the database
    $replace_test->execute($svnrev, $testtype) || die("$!");
    return 1;
  }
  return 0;
}


sub sched_next_tests {
  my ($testid, $svnrev, $testtype) = @_;

  if ($testtype=~/^smoke_/) {
    return;
  }
  ($cbs_config::test_target{$testtype} or $testtype=~/^special_/) or die("Unknown testtype '$testtype'");

  my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB: $!");
  my $select_special_backdep = $dbh->prepare('SELECT id, backdep FROM special_tests WHERE checkin=?') || die("$!");

  my $nexttests="";
  if ($testtype!~/^special_/) {
    $nexttests = $cbs_config::test_target{$testtype}->{'next'};
  }

  # See if any special tests rely on this one
  $select_special_backdep->execute($svnrev) || die("$!");
  while (my ($id, $backdep) = $select_special_backdep->fetchrow_array()) {
    if ($backdep eq $testtype) {
      $nexttests.=",special_$id";
    }
  }

  # Schedule the next test(s)
  foreach my $nexttest (split(/,/,$nexttests)) {
    if ($nexttest=~/^\s*$/) {
      next;
    }

    # Do not repeat if it is marked as done
    if (replace_test($svnrev, $nexttest)) {
      print "Inserting/Replacing test '$nexttest' ($svnrev) for scheduling on $cbs_config::release ...\n";
    }
  }
}


################################################################################


# For regressions
sub add_special_tests {
  my ($dbh, $svnrev, $user, $dir, $trgt, $timeout, $backdep, $simlist, $extra) = @_;

  ($backdep eq "" or $cbs_config::test_target{$backdep} or ($backdep=~/^special_/)) ||
    die("Unknown backdep '$backdep'");
  (-d "$cbs_config::top/$dir") or die("Directory '$cbs_config::top/$dir' does not exist");

  # Do not add duplicates
  my @rows = $dbh->selectrow_array("SELECT id FROM special_tests WHERE checkin=$svnrev AND "
				   ."dir='$dir' AND cmd='$trgt' AND extra='$extra'", {RaiseError=>1});
  if (scalar(@rows)) {
    return $rows[0];
  }

  my $temp_testid=10;
  $dbh->do("INSERT INTO special_tests VALUES(NULL,'$dir','$trgt','$user','$timeout',$temp_testid,$svnrev,"
	   ."'$backdep','$simlist','$extra')", {RaiseError=>1});
  my $special_id =  $dbh->{'mysql_insertid'};

  # This may add tests in the pending state when they could be run
  # This will cause a reschedule after the current SVN revision is tested even if it could be immedaitely run
  # but there is no easy way to do this.
  my $sql = sprintf("INSERT INTO tests VALUES(NULL,$svnrev,'special_$special_id',%d,%d,258,0,0,'',0)",
		    time(),time());
  $dbh->do($sql, {RaiseError=>1});
  my $testid =  $dbh->{'mysql_insertid'};

  $dbh->do("UPDATE special_tests SET testid=$testid WHERE id=$special_id", {RaiseError=>1});

  return $special_id;
}

################################################################################

# runsim does not like local and global cfg mixed e.g. this is bad
#   runsim -t <test>__<cfg_global>_<cfg local>
sub fix_up_runsim_cfg {
  my ($trgt, $extra) = @_;

  if ($extra ne "" && $trgt=~/__/) {
    return "echo \"bad test $trgt $extra\" && /bin/false ";
  }
  return "$trgt $extra";
}


# Encapsulates the naming scheme for log files
sub log_rev_test_filename {
  my ($rev, $test) = @_;
  my $file = sprintf("%d/r%d\.%s",$rev-($rev%100),$rev,$test);
  return $file;
}


# Move coverage results away so they are not deleted as the tree is cleaned
sub save_coverage_results {
  my ($svnrev) = @_;

  my @cov_dirs=glob("$cbs_config::top/dv/sim/*/cm");
  foreach my $cov_src (@cov_dirs) {
    my ($plat) = ($cov_src=~m|sim/(.+?)/cm|);
    my $cov_dst = "$cbs_config::covdir/$svnrev/$plat";
    system("mkdir -p $cov_dst");
    system("mv $cov_src $cov_dst");
    system("/bin/echo -e 'Coverage info from $cov_src\nNow saved at $cov_dst.\nNote only 4 coverage runs are kept' | mail -s 'cbs coverage run complete' rstonehouse\@solarflare.com achadha\@solarflare.com tchang\@solarflare.com");
  }

  # Garden old result - keep 4 revisions
  
}


# Coverage results are large - don't store too many
sub garden_coverage_results {
  my ($dbh) = @_;

  my $keep = $dbh->prepare('SELECT id FROM checkins WHERE coverage=1 ORDER BY id DESC LIMIT 4') || die("$!");
  $keep->execute() || die("$!");

  my %revs;
  while (my ($rev) = $keep->fetchrow_array()) {
    $revs{$rev}=1;
  }

  my @cov_dirs=glob("$cbs_config::covdir/*");
  foreach my $cov_src (@cov_dirs) {
    my $cov_dir = basename($cov_src);
    if ($revs{$cov_dir}) {
      print "Keeping $cov_dir\n";
    } else {
      print "Deleting $cov_dir\n";
      system("rm -Rf $cbs_config::covdir/$cov_dir");
    }
  }  
}


# Coverage commands are seperate (otherwise need to solve the problem of rescheduling the smoke
#  tests as platform builds are resued). This is to stop the multi-day view splitting
sub fixup_coverage_commands {
  my ($dbh, $svnid) = @_;

  my $select_specials = $dbh->prepare("SELECT id, cmd FROM special_tests WHERE checkin=?") || die("$!");
  my $update_special = $dbh->prepare("UPDATE special_tests SET cmd=? WHERE id=?") || die("$!");
  
  $select_specials->execute($svnid) || die("$!");
  while (my ($id, $cmd)=$select_specials->fetchrow_array()) {
    my $before = $cmd;
    $cmd=~s/ -cm//;
    print "$id '$before' -> '$cmd'\n";
    $update_special->execute($cmd, $id);
  }
}

1;
__END__
