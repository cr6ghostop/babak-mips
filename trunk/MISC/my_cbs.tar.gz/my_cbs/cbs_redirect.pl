#!/usr/bin/perl
#
# Redirect to the new server
#
# Robert Stonehouse
# Mar 2008
#
use strict;
use warnings;
use lib "/home/rjs/etc/perl-lib";

{
  package MyWebServer;
  
  use HTTP::Server::Simple::CGI;
  use base qw(HTTP::Server::Simple::CGI);

  my %dispatch = ('/' => \&handle_request);
  
  sub handle_request {
    my $self = shift;
    my $cgi  = shift;
    
    print "HTTP/1.1 301 Moved Permanently\r\n";
    print "Location: http://cbs.solarflarecom.com:1616/\r\n";
  }
}  

$main::pid = MyWebServer->new(1616)->background();
print "Use 'kill $main::pid' to stop server.\n";
