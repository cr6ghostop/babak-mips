#!/usr/bin/perl
################################################################################
# A continuous build system for the Siena RTL
# A script to do simple regexps in the database
################################################################################

use lib "/home/rjs/etc/perl-lib";
use strict;
use warnings;
use DBI;
use Time::ParseDate;
use File::Temp qw/ tempfile tempdir /;
use IPC::Open3;
use POSIX qw(strftime);

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";
$|=1;



# Command line paring and sanity checks
(scalar(@ARGV) == 0) or die("usage: $0");

# Setup
my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
my $select_cmds = $dbh->prepare("SELECT id, cmd  FROM comments") || die("$!");
my $update_cmd = $dbh->prepare("UPDATE comments SET cmd=? WHERE id=?") || die("$!");

$select_cmds->execute() || die("$!");
while (my ($id, $cmd)=$select_cmds->fetchrow_array()) {
  my $before = $cmd;
  $cmd=~s/runsim -cm/runsim/;
  print "$id '$before' -> '$cmd'\n";  
  $update_cmd->execute($cmd, $id);
}
