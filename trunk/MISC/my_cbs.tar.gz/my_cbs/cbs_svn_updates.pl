#!/usr/bin/perl
################################################################################
# A continuous build system for the Siena RTL
# This long lived process looks for changes from the SVN directory
#  runs a sequence of tests and writes the result to a database
# This script is designed to be run by the "cbs" shell wrapper which guarantees
#  that there is only one testing instance
#
# Robert Stonehouse
# Feb 2008
################################################################################

use lib "/home/rjs/etc/perl-lib";
use strict;
use warnings;
use DBI;
use Time::ParseDate;
use File::Temp qw/ tempfile tempdir /;

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";

my $dbh; # Database handle
my ($insert_checkin, $insert_test);

################################################################################

sub get_diff_counts {
  my ($rev) = @_;
  my %diffs; # keyed by filename
  my $filename;
  my $plus = 0;
  my $minus = 0;
  my $lastrev = int($rev ) - 1;
  my $first = 1;

# From svn diff:
#Index: lom/hdl/include/top.def
#===================================================================
#--- lom/hdl/include/top.def     (revision 0)
#+++ lom/hdl/include/top.def     (revision 9)
#@@ -0,0 +1,830 @@

  print "$cbs_config::svn diff --old=$cbs_config::repo\@$lastrev --new=$cbs_config::repo\@$rev\n";
  open(SVN,"$cbs_config::svn diff --old=$cbs_config::repo\@$lastrev --new=$cbs_config::repo\@$rev 2>&1 |") || die "$!";

  while (my $line=<SVN>) {
    if ($line=~/^Index: (.+)/) {
      if (!$first) { $diffs{$filename}="+$plus -$minus"; }
      $filename = $1;
      $plus = 0;
      $minus = 0;
      $first = 0;
      <SVN>; <SVN>; <SVN>; # Ignore 3 lines
    } elsif ($line=~/^\+/) {
      $plus++;
    } elsif ($line=~/^\-/) {
      $minus++;
    }
  }
  # There may be no output if only directories changed
  if ($filename) {
    $diffs{$filename}="+$plus -$minus";
  }
  close(SVN);
  
  return %diffs;
}


# merge svn log and svn diff output (as deleted file reporting is inconsistent)
sub get_info_on_rev {
  my ($rev, $author, $mytime, $_comments, $_filelist) = @_;
  my @comments = @{$_comments};
  my %filelist = %{$_filelist};

  print "Getting info on $rev $author $mytime\n";
  my %diffhash = get_diff_counts($rev);

  # merge
  foreach my $key (keys(%filelist)) {
    if (defined($diffhash{"$key"}) ) {
      $filelist{"$key"}.=" ".$diffhash{"$key"};
    }
  }

  # Convert to arrays
  my @files = keys(%filelist);
  my @diffs = values(%filelist);
  my $size = 0;
  
  print "Examining r$rev from $author at $mytime ..\n";
  my $svndate = parsedate("$mytime") || die("$!");
  $"="\n"; # Preserve newlines in @files, @comments and @diffs
  $insert_checkin->execute($rev, $author, "@comments", "@files", "@diffs", $svndate, time(), $size) || die("$!");
  
  # Insert the prepare test - will chain other tests after it completes
  $insert_test->execute($rev, $cbs_config::first_test_for_new_update) || die("$!");
}


# For a given revision extract info from SVN to go into the database
# This is needed to make the web display more useful
sub get_info_on_new_revs {
  my ($latest_db_rev) = @_;
  my @revs;
  my ($rev, $author, $mytime);
  my $comments = undef;
  my $filelist = undef;

# From svn log: -v
#------------------------------------------------------------------------
#r1938 | ebrenes | 2008-05-29 11:02:44 -0700 (Thu, 29 May 2008) | 1 line
#Changed paths:
#   M /SFL9021AA/lom/hdl/include/csr_mc.def
#
#Update.Fixed redefinition of FLR base
#------------------------------------------------------------------------

  open(SVN,"$cbs_config::svn log -v $cbs_config::repo 2>&1 |") or die("Could not run svn log '$!'");
  # Note that it has to be done this way as SVN can skip revisions

  my $state= "revision";
  my $line = <SVN>;
  chop $line;
  if ($line ne "-"x72) {
    my $nextline = <SVN>;
    die "Bad svn log line '$line\n $nextline'";
  }
  
  while ($line=<SVN>) {
    chop $line;

    # State machine for going through the log parts
    if ($state eq "revision") {
      (($rev, $author, $mytime) = ($line=~/^r(\d+) \| (\w+) \| (.+? .+? .+?) /))
	or die("Unexpected svn revision line '$line'");
      $state = "changed_paths";

    } elsif ($state eq "changed_paths") {
      my $expect="Changed paths:";
      ($line eq $expect) || die "Bad svn log line expected '$expect' got '$line'";
      $state = "filelist";

    } elsif ($state eq "filelist") {
      
      if ($line eq "") {
	$state="comment";
      } else {
	if (!($line=~/   (.) \/SFL9021AA\/(.*)/)) {
	  die("Bad svn log line in filelist '$line'");
	}
	$filelist->{"$2"}="$1";
      }

    } elsif ($state eq "comment") {
      if ($line eq "-"x72) {
	
	if ($rev == $latest_db_rev) {
	  # Must get here or else die at the end of the loop
	  close(SVN);
	  # Must do this oldest to newest revision so that it recovers if killed
	  # at any point	
	  while (scalar(@revs)) {
	    my ($r, $a ,$t, $c ,$f) = @{pop @revs};
	    get_info_on_rev($r, $a, $t, $c, $f);
	  }
	  # NB return here NB
	  return;
	}
	print "Adding $rev from $author to the list of items to consider\n";
	my @thisrev = ($rev, $author, $mytime, $comments, $filelist);
	push @revs, \@thisrev;
	
	# reset state
	$state = "revision";
	$comments = undef;
	$filelist = undef;
      } else {
	push @{$comments}, "$line";
      }
    } else {
      die("Bad state '$state'");
    }
  }
  die("Did not find the last know revision '$latest_db_rev' in svn log");
}


################################################################################
$|=1;

# Command line paring and sanity checks
(scalar(@ARGV) == 0) or die("usage: $0");

# Setup
$dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
$insert_checkin = $dbh->prepare('INSERT INTO checkins VALUES (?,?,?,?,?,?,?,?,0,0)') || die("$!");
$insert_test        = $dbh->prepare("INSERT INTO tests VALUES (NULL,?,?,0,0,256,0,0,'',0)") || die("$!");

while (1) {
 if ($cbs_config::update_from_svn) {
    my $latest_db_rev = cbs_common::latest_db_svnid();
    get_info_on_new_revs($latest_db_rev);
  }

  # Nothing to do ... zzzzzz ....
  sleep($cbs_config::svnpoll);
}
