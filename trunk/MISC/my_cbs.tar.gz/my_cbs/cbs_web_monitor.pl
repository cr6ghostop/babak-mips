#!/usr/bin/perl
#
# This component tries to make it easy for users to kill parts of cbs if 
# it is misbehaving
#
# Robert Stonehouse
# Feb 2008
#
use strict;
use warnings;

use lib "/home/rjs/etc/perl-lib";
use DBI;
use POSIX qw(strftime SIGCHLD);

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";

{
  package MyWebServer;
  
  use HTTP::Server::Simple::CGI;
  use base qw(HTTP::Server::Simple::CGI);

  my %dispatch = ('/offline'  => \&resp_offline,
		  '/control'  => \&resp_control,
		  '/kill_pid' => \&resp_kill_pid,
		  '/cbs_cmd'  => \&resp_cbs_cmd);
  

  sub handle_request {
    my $self = shift;
    my $cgi  = shift;
    
    my $path = $cgi->path_info();
    my $handler = $dispatch{$path};
    
    if (ref($handler) eq "CODE") {
      print "HTTP/1.0 200 OK\r\n";
      $handler->($cgi);
    } else {
      print "HTTP/1.0 404 Not found\r\n";
      print $cgi->header,
      $cgi->start_html('Not found'),
      $cgi->h1('Not found'),
      $cgi->end_html;
    }
  }


  sub resp_offline {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    
    print $cgi->header, $cgi->start_html(-title=>"Siena RTL Continuous Build System (CBS)");
    print "<H1>Sorry - cbs offline</H1>\n";
    print "Suffering from problems with automount and SVN reliability<BR>\n";
    print "A version that runs from local disk is coming soon<BR>\n";
    print "Rob - 20080602";
    print $cgi->end_html;
  }


  sub resp_control {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    
    print $cgi->header, $cgi->start_html(-title=>"Siena RTL Continuous Build System (CBS)");
    print "<pre>\n";
    open(PS, "ps ux|");
    while (my $line = <PS>) {
      print $line;
    }
    close(PS);
    print "</pre>\n";

    print <<'EOF';
<FORM ACTION="/kill_pid" method="GET">
Process ID
<INPUT type="text" name="pid">
<INPUT type="submit" value="Kill">
</FORM>

<FORM ACTION="/cbs_cmd" method="GET">
CBS command (e.g. restart/restart_web/restart_reparser/check)
<INPUT type="text" name="cbs_cmd">
<INPUT type="submit" value="Do">
</FORM>

EOF
    print $cgi->end_html;
  }


  sub redirect {
    my ($cgi, $url) = @_;
    print $cgi->header, $cgi->start_html(
	-head => ["<meta http-equiv=\"refresh\" content=\"0;url=$url\">"] );
    print $cgi->end_html;    
  }


  sub resp_kill_pid {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $pid = $cgi->param('pid');
    kill "SIGINT", $pid;
    sleep 1;
    kill "SIGKILL", $pid;
    redirect($cgi, "/control");
  }

  sub resp_cbs_cmd {
    my $cgi  = shift;   # CGI.pm object
    return if !ref $cgi;
    my $cbs_cmd = $cgi->param('cbs_cmd');

    print $cgi->header;
    open(CBS, "cbs $cbs_cmd 2>&1 |") || die;
    print "<pre>";
    while (my $line=<CBS>) {
      chop $line;
      print "$line<BR>\n";
    }
    print "</pre>";
    close(CBS);

    print $cgi->end_html;
  }


}

$main::pid = MyWebServer->new($cbs_config::ctrlport)->background();
print "Use 'kill $main::pid' to stop server.\n";

open(PID, ">$cbs_config::piddir/cbs_web_monitor") || die;
print PID "$main::pid\n";
close(PID);
