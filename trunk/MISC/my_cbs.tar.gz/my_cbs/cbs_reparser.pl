#!/usr/bin/perl
################################################################################
# A continuous build system for the Siena RTL
# This long lived process looks for tests that are marked as reparse
################################################################################

use lib "/home/rjs/etc/perl-lib";
use strict;
use warnings;
use DBI;
use Time::ParseDate;
use File::Temp qw/ tempfile tempdir /;
use IPC::Open3;
use POSIX qw(strftime);

# Find cbs_config.pm from the same directory
use Cwd 'abs_path';
use File::Basename;
use lib abs_path(dirname($0));
use cbs_config;
use cbs_common;

$ENV{'PATH'} = "/bin:/usr/bin:/usr/local/bin:$cbs_config::svn";
$ENV{'LD_LIBRARY_PATH'} = "$cbs_config::svnlib";
$|=1;

my @error_whitelist   = map { qr/($_)/i } @cbs_config::error_whitelist;
my @error_words       = map { qr/($_)/i } @cbs_config::error_words;
my @warning_whitelist = map { qr/($_)/i } @cbs_config::warning_whitelist;
my @warning_words     = map { qr/($_)/i } @cbs_config::warning_words;

# Command line paring and sanity checks
(scalar(@ARGV) == 0) or die("usage: $0");

# Setup
my $dbh = DBI->connect("$cbs_config::dbconnect", "", "") or die("Could not connect to DB");
my $select_tests = $dbh->prepare("SELECT id, checkin, testtype FROM tests WHERE rc=$cbs_config::rc_reparse") || die("$!");
my $update_parse = $dbh->prepare("UPDATE tests SET rc=0,n_errors=?,n_warnings=? WHERE id=?") || die("$!");
my $update_logmissing = $dbh->prepare("UPDATE tests SET rc=$cbs_config::rc_logmissing WHERE id=?") || die("$!");

################################################################################

sub parse_log {
  my ($id, $logfile) = @_;
  my $n_errors = 0;
  my $n_warnings = 0;

  if (!-f "$logfile.gz") {
    print(" ... could not find '$logfile.gz' so not updating\n");
    $update_logmissing->execute($id) || die("$!");
    return;
  }

  open(LOG, "zcat $logfile.gz |") || die("Could not open '$logfile.gz': $!");
  while (my $line=<LOG>) {
    
    foreach my $word (@error_whitelist) {
      $line=~s/$word//g;
    }
    foreach my $word (@error_words) {
      if ($line=~/$word/g) { $n_errors++; }
    }
    foreach my $word (@warning_whitelist) {
      $line=~s/$word//g;
    }
    foreach my $word (@warning_words) {
      if ($line=~/$word/g) { $n_warnings++; }
    }
  }
  close(LOG);

  # Update the database
  print " ... reparsed n_errs $n_errors n_warn $n_warnings\n";
  $update_parse->execute($n_errors, $n_warnings, $id) || die("$!");
}

################################################################################



# Main
while (1) {
  $select_tests->execute() || die("$!");
  while (my ($id, $checkin, $testtype) = $select_tests->fetchrow_array()) {
    my $logfile = cbs_common::log_rev_test_filename($checkin, $testtype);
    print("Reparsing id $id checkin $checkin '$logfile'\n");

    parse_log($id, "$cbs_config::logdir/$logfile");
  }

  sleep(5);
}
