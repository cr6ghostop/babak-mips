#!/bin/env perl

# This script adds timestamps to each line of a log file
# It only rereads the time every 1 sec via a timer so can handle lots of output

use strict;
use warnings;
use POSIX qw(strftime);

my $prefix;
$| = 1; # Autoflush on
my $starttime = time();

sub set_prefix {
    $prefix = strftime("%H:%M:%S> ", localtime());
}

$SIG{ALRM} = sub {
    set_prefix();
    alarm(1);
};

set_prefix();
alarm(1);

while (my $line=<>) {
    print "$prefix$line";
}

print strftime("\n=== total time: %H:%M:%S ===\n", gmtime(time()-$starttime));

exit 0;
