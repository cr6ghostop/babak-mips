# This is a safety feature to ensure that only one copy can run at once
# and we know if it is the running or testing release

package cbs_config;
use strict;
use warnings;

$cbs_config::hostname = `hostname`;
$cbs_config::hostname = (split(/\./,$cbs_config::hostname))[0];

$cbs_config::running_host = "nicklaus";
$cbs_config::testing_host = "pick";

# Determine the release from override in included program or hostname
if ($main::argv0_is_release) {
  $cbs_config::release = $ARGV[0];
} else {
  if ($cbs_config::hostname eq $cbs_config::running_host) {
    $cbs_config::release = "running";
  } elsif ($cbs_config::hostname eq $cbs_config::testing_host) {
    $cbs_config::release = "testing";
  } else {
    die("Unknown host $cbs_config::hostname not running:$cbs_config::running_host or testing:$cbs_config::testing_host");
  }
}
($cbs_config::release eq "running" || $cbs_config::release eq "testing") || die("Unknown release '$cbs_config::release'");

$cbs_config::min_checkin = 50; # Go back this many revisions from top of tree
if ($cbs_config::release eq "running") {
  $cbs_config::server = "cbs.solarflarecom.com";
} else {
  $cbs_config::server = $cbs_config::testing_host;
}
$cbs_config::webport  = 1616;
$cbs_config::ctrlport = 1617;
$cbs_config::dbport   = 1618;
$cbs_config::proj = "SFL9021AA";
$cbs_config::qsub = "/tools/solarflare/sfdsTools/qsub -N cbs_$cbs_config::release -p -800"; 
$cbs_config::qdel = "/tools/solarflare/sfdsTools/qdel";
$cbs_config::qstat = "/tools/solarflare/sfdsTools/qstat";
$cbs_config::default_queue = "dig_lnx_M4";

$cbs_config::update_from_svn = ($cbs_config::release eq "running") ? 1 : 0;
$cbs_config::usegrid = 1; # Without grid is broken

# This is now controlled by lic_vcs - this is just a maximum
$cbs_config::grid_max_jobs = ($cbs_config::release eq "running") ? 40 : 8;

$cbs_config::motd = "Message of the day (Tue 17th): Overnight regression hasn't got very far due to licensing problems";

$cbs_config::svnpoll = 20; # SVN poll interval in seconds
$cbs_config::dbpoll = 5; # DB poll for pending/running tests in seconds

$cbs_config::max_checkin_repeats = 5; # Number of times to start working on the same checkin
                                      # otherwise abort as possible scheduling loop

# Location of the working tree
$cbs_config::svnmod = "lom";
$cbs_config::top_local = "/local/$cbs_config::proj/Work/$ENV{'USER'}/cbs";
$cbs_config::top_filer = "/projects/$cbs_config::proj/Work/$ENV{'USER'}/cbs";
$cbs_config::abovetop  = "$cbs_config::top_filer/$cbs_config::release";
$cbs_config::top       = "$cbs_config::abovetop/$cbs_config::svnmod";
$cbs_config::covdir    = "$cbs_config::abovetop/coverage";

# SVN access methods
$cbs_config::repo_dir = "repo_$cbs_config::proj/$cbs_config::proj";
$cbs_config::repo_http = "http://ocsync01.solarflarecom.com/svn/$cbs_config::repo_dir";
$cbs_config::repo_file = "file:///vault/subversion/$cbs_config::repo_dir";
$cbs_config::repo = $cbs_config::repo_http;

# SVN locations
# Assumes 'source /home/solarflare/environment/.cshrc.sfds' run in users .cshrc
# Problems with automounts mean a local copy is necessary
$cbs_config::svn = '/tools/solarflare/sfdsTools/svn';
$cbs_config::svnlib = '';

# CBS locations
$cbs_config::base_filer = "/home/$ENV{'USER'}/cbs";
$cbs_config::base_local = "/local/$ENV{'USER'}/cbs";
$cbs_config::base = $cbs_config::base_filer;
$cbs_config::relbase = "$cbs_config::base/$cbs_config::release";

$cbs_config::bin      = "$cbs_config::relbase/code";
$cbs_config::sqlitedb = "$cbs_config::relbase/cbs_db/siena_cbs.db"; # old sqlite
$cbs_config::logdir   = "$cbs_config::relbase/cbs_logs";
$cbs_config::joblogs  = "$cbs_config::relbase/job_logs";
$cbs_config::jobcmds  = "$cbs_config::relbase/job_cmds";


# Don't need to contain the release as the machine they are run on determine this
$cbs_config::mainlog = "$cbs_config::relbase/main_logs";
$cbs_config::piddir  = "$cbs_config::relbase/pids";
$cbs_config::sfdsfail= "$cbs_config::relbase/sfdsfail";

$cbs_config::timeout   = "$cbs_config::bin/cbs_timeout.pl";
$cbs_config::timestamp = "$cbs_config::bin/cbs_timestamp.pl";
$cbs_config::run_one   = "$cbs_config::bin/cbs_run_one.pl";
$cbs_config::build     = "$cbs_config::bin/cbs_build.pl";


if ($cbs_config::release eq "running") {
  # Mysql does not like the CNAME for cbs when connecting locally
  if ($cbs_config::hostname eq $cbs_config::running_host) {
    $cbs_config::dbconnect_mysql = "dbi:mysql:database=running;host=127.0.0.1;port=$cbs_config::dbport;user=running;password=bar518040"; # cbs - 1 ascii char + UK phone
  } else {
    $cbs_config::dbconnect_mysql = "dbi:mysql:database=running;host=$cbs_config::running_host;port=$cbs_config::dbport;user=running;password=bar518040"; # cbs - 1 ascii char + UK phone
  }
} elsif ($cbs_config::release eq "testing") {
  if ($cbs_config::hostname eq $cbs_config::testing_host) {
    $cbs_config::dbconnect_mysql = "dbi:mysql:database=testing;host=127.0.0.1;port=$cbs_config::dbport;user=testing;password=dct518040"; # cbs + 1 ascii char + UK phone
  } else {
    $cbs_config::dbconnect_mysql = "dbi:mysql:database=testing;host=$cbs_config::testing_host;port=$cbs_config::dbport;user=testing;password=dct518040"; # cbs + 1 ascii char + UK phone
  }
}
$cbs_config::dbconnect_sqlite = "dbi:SQLite:dbname=$cbs_config::sqlitedb";
$cbs_config::dbconnect = $cbs_config::dbconnect_mysql;
$cbs_config::dbdir = "/local/$ENV{'USER'}/cbs/$cbs_config::release/mysql";


# Add tests here - no spaces in names
# Please do not change the name of "smoke" it is special
# TODO add regexp to determine if a test is needed
# Prepare timeout is long as might need to clean the tree. This takes a loooooong time
# next list is used in list order


# This is a test mode to be used on the testing release
$cbs_config::simple_tests = 0;

# Changes to runsim affects how comments correlate
# Use cbs_fix_comments.pl
my $runsim='runsim -uniqlog -nogrid -rnd -no_verdi -no_debug -v "+PCIE_MON_DIS=1"';
my $runsim_cov='runsim -cm -uniqlog -nogrid -rnd -no_verdi -no_debug -v "+PCIE_MON_DIS=1"';

if ($cbs_config::simple_tests && $cbs_config::release eq "testing") {

  $cbs_config::usegrid = 0;
  
  # Noddy tests (for speed of testing) - 'prepare' must be the first test
  $cbs_config::first_test_for_new_update = 'a';
  %cbs_config::test_target = 
    ('a'=>{'next'=>'b,c', 'dir'=>'/tmp',                          'timeout'=>60},
     'b'=>{'next'=>'d',   'dir'=>'/tmp', 'trgt'=>'/bin/sleep 5',  'timeout'=>60},
     'c'=>{               'dir'=>'/tmp', 'trgt'=>'/bin/sleep 15', 'timeout'=>60},
     'd'=>{               'dir'=>'/tmp', 'trgt'=>'/bin/sleep 5',  'timeout'=>3},
     );
  
} else {

  # Real test definitions - 'prepare' must be the first test
  $cbs_config::first_test_for_new_update = 'prepare';

  # Note ensure that the system is IDLE with no outstanding tests before restarting with new tests
  # Tests *MUST NOT* do their own grid submission
  %cbs_config::test_target =
    ('prepare'=> {'next'=>'nodut_tb_compile,platm_tb_compile,asic_mbist_tb_compile,asic_tb_compile,cosim_compile,lint_bethpage,dv_regdef,siena_tb_compile',
		  'timeout'=>15*60,
		  'shortname'=>'prep'},
     #### Platform compiles #####
     'nodut_tb_compile' =>{'dir'=>'dv/sim/bethpage.nodut',
			   'trgt'=>"$runsim -co",
			   'timeout'=>10*60,
			   'shortname'=>'ndut',
			   'lic'=>'lic_vcs_comp=1'},
     'asic_mbist_tb_compile' =>{'dir'=>'dv/sim/bethpage.asic_mbist',
                                'trgt'=>"$runsim -co",
                                'next'=>'smoke',
                                'timeout'=>12*60,
                                'shortname'=>'asic_mbist',
                                'queue'=>'dig_lnx_M4',
                                'lic'=>'lic_vcs_comp=1'},
     'asic_mbist_tb_compile_cov' =>{'dir'=>'dv/sim/bethpage.asic_mbist',
				    'trgt'=>"$runsim_cov -co",
				    'timeout'=>12*60,
				    'shortname'=>'asic_mbist',
				    'queue'=>'dig_lnx_M4',
				    'lic'=>'lic_vcs_comp=1',
				    'backdeps'=>'prepare'},
     'asic_tb_compile' =>{'dir'=>'dv/sim/bethpage.asic',
                          'trgt'=>"$runsim -co",
                          'timeout'=>12*60,
                          'shortname'=>'asic',
                          'queue'=>'dig_lnx_M4',
                          'lic'=>'lic_vcs_comp=1'},
     'asic_tb_compile_cov' =>{'dir'=>'dv/sim/bethpage.asic',
			      'trgt'=>"$runsim_cov -co",
			      'timeout'=>12*60,
			      'shortname'=>'asic',
			      'queue'=>'dig_lnx_M4',
			      'lic'=>'lic_vcs_comp=1',
			      'backdeps'=>'prepare'},
     'siena_tb_compile' =>{'dir'=>'dv/sim/siena.siena_nopcie',
			   'trgt'=>"$runsim -co",
			   'timeout'=>12*60,
			   'shortname'=>'siena',
			   'queue'=>'dig_lnx_M4',
			   'next'=>'siena_smoke',
			   'lic'=>'lic_vcs_comp=1'},
     'siena_tb_compile_cov' =>{'dir'=>'dv/sim/siena.siena_nopcie',
			       'trgt'=>"$runsim_cov -co",
			       'timeout'=>12*60,
			       'shortname'=>'siena',
			       'queue'=>'dig_lnx_M4',
			       'lic'=>'lic_vcs_comp=1',
			       'backdeps'=>'prepare'},
     # Entry needed for SV regressions
     'asic_tb_nopcie_compile' =>{'dir'=>'dv/sim/bethpage.nopcie',
				 'trgt'=>"$runsim -co",
				 'timeout'=>12*60,
				 'shortname'=>'asic nopcie',
				 'queue'=>'dig_lnx_M4',
				 'lic'=>'lic_vcs_comp=1',
				 'backdeps'=>'prepare'},
     'asic_tb_nopcie_compile_cov' =>{'dir'=>'dv/sim/bethpage.nopcie',
				     'trgt'=>"$runsim_cov -co",
				     'timeout'=>12*60,
				     'shortname'=>'asic nopcie',
				     'queue'=>'dig_lnx_M4',
				     'lic'=>'lic_vcs_comp=1',
				     'backdeps'=>'prepare'},
     #### FPGA Platform compiles #####     
     'plaths_tb_compile' =>{'dir'=>'dv/sim/bethpage.platform_hs',
			    'trgt'=>"$runsim -co",
			    'timeout'=>10*60,
			    'shortname'=>'hs comp',
			    'lic'=>'lic_vcs_comp=1',
			    'disabled_in_testing'=>1},
     'platm_tb_compile' =>{'dir'=>'dv/sim/bethpage.platform_m',
			   'trgt'=>"$runsim -co",
			   'timeout'=>10*60,
			   'shortname'=>'platm comp',
			   'lic'=>'lic_vcs_comp=1',
			   'disabled_in_testing'=>1},
     #### FPGA Platform synthesis #####
     'hs_synth' =>{'next'=>'platm_synth',
		   'dir'=>'vald/fpga/altera/synth',
		   'trgt'=>'make PLATFORM=hs340',
		   'timeout'=>20*60,
		   'onlyfor'=>'hdl/,vald/fpga/,impl/',
		   'queue'=>'dig_lnx_M4',
		   'nextonerr'=>1,
		   'disabled_in_testing'=>1},
     'platm_synth' =>{'dir'=>'vald/fpga/altera/synth',
		      'trgt'=>'make PLATFORM=platform_m',
		      'timeout'=>15*60,
		      'onlyfor'=>'hdl/,vald/fpga/',
		      'queue'=>'dig_lnx_M4',
		      'disabled_in_testing'=>1},
     #### Random other tests  #####
     'lint_bethpage'=>{'dir'=>'lint/bethpage',
		       'trgt'=>'make GRID= run_sg_fast',
		       'timeout'=>30*60,
		       'shortname'=>'lint',
		       'savelogs'=>'moresimple.rpt,spyglass_reports/moresimple.rpt',
		       'oneinn'=>32,
		       'disabled_in_testing'=>1},
     'dv_regdef' =>{'dir'=>'dv/share/build/regdef',
		    'trgt'=>'make GRID=',
		    'timeout'=>10*60,
		    'shortname'=>'rdef'},
     'siena_smoke' =>{'dir'=>'dv/sim/siena.siena_nopcie',
		      'trgt'=>"$runsim -t calip_basic_lb__xgmii",
		      'timeout'=>10*60,
		      'shortname'=>'siena_smk',
		      'lic'=>'lic_vcs=1'},
     #### Psuedo tests #####
     # This tests spawns other tests from the testlist in cbs_build.pl
     'smoke' =>{'dir'=>'dv/sim/bethpage.asic_mbist',
		'trgt'=>"$runsim -t",
		'timeout'=>10*60,
		'shortname'=>'smk',
		'nowebdisplay'=>1,
		'lic'=>'lic_vcs=1,lic_dw_reg=1'},
     # This is used to record how to use runsim
     'special' =>{'trgt'=>"$runsim -t",
		  'timeout'=>10*60,
		  'shortname'=>'spc',
		  'nowebdisplay'=>1,
		  'lic'=>'lic_vcs_reg=1,lic_vcs=1',
		  'nextonerr'=>1},
     'special_cov' =>{'trgt'=>"$runsim_cov -t",
		      'timeout'=>10*60,
		      'shortname'=>'spc',
		      'nowebdisplay'=>1,
		      'lic'=>'lic_vcs_reg=1,lic_vcs=1',
		      'nextonerr'=>1},
     #### Cosim stuff #####
     # ensure serial - only 1 cosim can be running per machine (port clash)
     # note that platform hs consumes cosim XFI shell
     'cosim_compile' =>{'dir'=>'dv/cosim',
			'trgt'=>'make GRID= MC=1 DEBUG_TX=1 COSIM_MC_SHM_MONITOR=1',
			'timeout'=>2*60,
			'next'=>'cosim_trivial,hs_synth,plaths_tb_compile',
			'nextonerr'=>1,
			'shortname'=>'cosim comp',
			'lic'=>'lic_vcs_comp=1,lic_vcs=1,lic_dw_reg=1'},
     'cosim_trivial' =>{'dir'=>'dv/cosim',
			'trgt'=>'/home/rjs/cosim/releases/latest/esnap --simv ./simv trivial^z',
			'timeout'=>6*60,
			'next'=>'cosim_mc',
			'nextonerr'=>1,
			'shortname'=>'cosim triv',
			'queue'=>'dig_lnx_M4',
			'lic'=>'lic_vcs=1,lic_dw_reg=1'},
     'cosim_mc' =>{'dir'=>'dv/cosim',
		   'trgt'=>'/home/rjs/cosim/releases/latest/esnap --simv ./simv -- mcdi@shm=port/mcshm:0/vi/nic mcdiop.mc_get_version^z',
		   'timeout'=>6*60,
		   'shortname'=>'cosim mc',
		   'queue'=>'dig_lnx_M4',
		   'lic'=>'lic_vcs=1,lic_dw_reg=1'},
     # TODO This is run after all other tests
     'last'=>{'next'=>'get_size'},
     'get_size'=>{'timeout'=>5*60,
		  'nowebdisplay'=>1},
     );

}

# Backwards dependancies
%cbs_config::back_deps = (
 "$cbs_config::first_test_for_new_update"=>'none',
);


# E-mail sent
@cbs_config::sfds_errors = ('^\*\*\* SFDS command not found error:',
			    '^dproj_new.pl: Command not found',
			    '^qsubs command error',
			    '^Can.t open perl script ./tools/solarflare/sfdsTools/perl.: No such file or directory',
			    '^Cannot find license file',
			    'Unable to locate ucapi library',
			    'error: sge_gethostbyname failed');
# No e-mail sent
@cbs_config::sfds_silent_errors = ('^Your .qrsh. request could not be scheduled, try again later',
				   'No space left on device');
#				   'Licensed number of users already reached',
#				   'License checkout failure');

@cbs_config::sfds_errors_notify = ('rstonehouse', 'dslocombe');
$cbs_config::sfds_fail_amnesty = 60*5; #amensty

# Ignore spurious errors and warnings
# Try not to ignore real errors that might be in these unhelpfully named files
@cbs_config::error_words = ('error', 'failed', 'failure', 'fatal');
# NB these are used as regular expressions
@cbs_config::error_whitelist = ('cdm_error_reg',
                                'lcrc_error_rate',
				'cdm_vf_error',
                                'xgrxalignerror_reg',
                                'xgrxfcserrorpkts_reg',
                                'xgrxinternalmacerror_reg',
                                'xgrxlengtherror_reg',
                                'xgrxsymbolerror_reg',
                                'xgrxundersizefcserrorpkts_reg',
				'error_log_pipeline', 
				'sim/error_test',
				'ipv4_ckserror.dat',
				'ipv6_ckserror.dat',
				'PciePhyErrorInjection',
				'error_test',
				'0 error',
				'Advanced Error Reporting',
				'0 demoted errors',
				'error in a future release',
				'this will be an error',
				'total test cases failed: 0',
				'WARNING.FAILURE.',
				'Failed to disable AUX port',
				'parsed_n_errors',
				'assert_mutex: started at 0fs failed at 0fs',
				'SVA_CHECKER_ERROR : ASSERT_MUTEX : MUTEX :\s*: severity 1 : time 0 : [\w\.]+\.sva_checker_error',
				'svn status \| tee svnstatus. failed rc=1',
				'Text macro \(SEVERITY_ERROR\)',
				'snapper: Squashing error for now',
				'pcie_errors.sv',
				'pcie_errors_s.svh',
				'DevCtl:\s+Report errors:\s+Correctable\+ Non-Fatal\+ Fatal\+ Unsupported\-',
				'snapper: Squashing the error for now',
				'nput.output error',
				'm_bPoisonedTlpAdvNonFatal = VMT_BOOLEAN',
				'port._fatal_intr_reg_char:\s+RstVal==OpVal',
				'port._fatal_intr_reg_ker:\s+RstVal==OpVal',
				'0 fatal',
				'DevSta:\s+CorrErr. UncorrErr. FatalErr. UnsuppReq. AuxPwr. TransPend.',
				'failed to get a good estimate for loops_per_jiffy',
				'ERR_NONFATAL received from DUT. ignoring',
				'Putting errors on the following queue',
				'X_DSC_ERROR_EV',
				'DevCtl.\s*Report errors.\s*Correctable. Non-Fatal. Fatal. Unsupported.',
				'The force parity error in SRAM bit is set to',
				'failed .correct behaviour',
				'DBI read for 0x... failed .Function not implemented.',
				'IGNORE_NONFATAL_ERR = ',
				'IGNORE_FATAL_ERR = ',
				'error_limit =',
				'X_DSC_ERROR_EV',
				'FATAL: Module mtdchar not found',
				'snapper: failed to invoke MCDI copycode operation',
				'EXPT_NET_IVEC_FATAL_INT_P',
				'error_limit =',
				'PCIE_MON_STOP_AFTER_N_ERRORS',
				'total errors: 0',
				'Rcvd\s*RX\s*FLS\s*FAILED\s*event',
				'error..License server system does not support this feature',
				'error..License server does not support this feature',
				'error..Licensed number of users already reached',
				'error..Cannot find license file',
				'FLEXlm error',
				'System Error: 2 .No such file or directory.',
				'The connect.. system call failed',
				'FATAL_INTR_REG',
				'NET_IVEC_FATAL_INT',
				'FLEXlm checkout error',
				'FLEXnet Licensing checkout error',
				'FLEXnet Licensing error',
				'-Werror',
                                'librterrorinf.so',
                                'liberrorinf.so',
				'Text macro .CX_ERROR_LOG_REGOUT. is redefined',
				'blocked_error_in_d13_vf_mod',
                                'IGNORE_FINAL_FATAL_INTR_STS'

);
# NB these are used as regular expressions

@cbs_config::warning_words = ('warning');
# NB these are used as regular expressions
@cbs_config::warning_whitelist = ('0 warning',
				  '0 demoted warning',
				  'parsed_n_warnings',
				  'Warning: no access to tty .Bad file descriptor.',
				  'RT warning: No condition matches in .unique case. statement',
				  'Warning: Can.t open rom512x32_cm16.hex: No such file or directory',
				  'Warning: \$readmem: cannot open file .rom512x32_cm16.hex',
				  'Warning: Can.t open rom512x32_cm16_ase.hex: No such file or directory',
				  'Warning: \$readmem: cannot open file .rom512x32_cm16_ase.hex',
				  'warning: implicit declaration of function .ConvUP2LLI.',
				  'warning: libstdc\+\+.so.5, needed by',
				  'WARNING: UNPROTECTED PRIVATE KEY FILE',
				  'ERR: WARNING: the Solarflare Network Adapter has been plugged into a PCI-Express slot with less than 8 lanes',
				  'snapper: WARNING: Siena MAC ops need finishing',
				  'warnings: 0'
);
# NB these are used as regular expressions


%cbs_config::timeouts = ('bill'=>1.5,
			 'bolt'=>1.5,
			 'aster'=>1.5,
			 'binge'=>1.5);

# return code meanings
#                               110 is timeout
$cbs_config::rc_newtest       = 256;
$cbs_config::rc_setupfail     = 257;
$cbs_config::rc_resched       = 258; # testing a newer revision preempted this
$cbs_config::rc_running       = 259;
$cbs_config::rc_unnecessary   = 260;
$cbs_config::rc_rerun_sfds    = 261; # tool not found.
$cbs_config::rc_runsim_abort  = 262; # smoke finished but no result
$cbs_config::rc_parsefail     = 263;
$cbs_config::rc_forcedfail    = 264;
$cbs_config::rc_forcedunknown = 265;
$cbs_config::rc_smokefail     = 267;
$cbs_config::rc_disabled      = 268;
$cbs_config::rc_unknowntest   = 269;
$cbs_config::rc_pendgrid      = 270;
$cbs_config::rc_gridfail      = 271;
$cbs_config::rc_badbackdep    = 272; # Tried to reschedule but never got to this test
$cbs_config::rc_reparse       = 273;
$cbs_config::rc_logmissing    = 274;



1;
__END__
