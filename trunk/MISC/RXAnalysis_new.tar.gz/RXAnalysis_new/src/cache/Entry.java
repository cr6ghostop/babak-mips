/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cache;

import java.io.File;
import java.util.List;

/**
 *
 * @author bazimi
 */
public class Entry {

List<File> file;
File dir;
String Xlabel;
String Ylabel;
String title;
String text;
int port;

       Entry(List<File> _file, String _title, String _Xlabel, String _Ylabel, int _port)
       {
        file = _file;
        title = _title;
        Xlabel = _Xlabel;
        Ylabel = _Ylabel;
        port = _port;
       }


}
