/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cache;

/** This Class plots the result of mini-regression tests for cache analysis.
 *
 * @author bazimi
 */
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import ptolemy.plot.*;
import java.awt.*;
import javax.swing.*;
import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.io.*;
import java.util.Map;
import java.util.HashMap;


public class CacheAnalysis extends JFrame {


    /** We use a constructor here so that we can call methods
     *  directly on the Frame.  The main method is static
     *  so getting at the Frame is a little trickier.
     */


    int NUM_PORTS = 2;

    // Entries
    static List<Entry>  entry = new ArrayList<Entry>();
    //static List<File>   holders = new ArrayList<File>();
    static List<File>   holders;

    // parsed vars
    static String queueName;
    static String cacheName;
    static String packetName;
    static String genName;
    static String fullName;
    static String platName;
    static String infoBuffer;

    // directories needed
    static File currDir;
    static File projDir;
    static File tcaseDir;
    static File rxperfDir;
    static File dataDir;
    static File simDir;
    static File port0Dir;
    static File port1Dir;

    // files needed
    static File ffDepthFile[] = new File[2];
    static File ffPktNumFile[] = new File[2];
    static File dropFifoFullFile[] = new File[2];
    static File dropNoDescFile[] = new File[2];
    static File wtrmarkFile[] = new File[2];
    static File thruPutFile[] = new File[2];

    // cache file names
    static String port0FileName[];
    static String port1FileName[];

    // cache files
    static File port0File[];
    static File port1File[];


    public static void addEntry(List<File> _file, String _title,
                                 String _Xlabel, String _Ylabel, int _port)
    {
       Entry localEntry = new Entry(_file, _title, _Xlabel, _Ylabel, _port);
       CacheAnalysis.entry.add(localEntry);

    }


    public static JPanel infoPanel(String info)
    {
        String myText = "This is a test";

        JButton button = new JButton("Test Button");
        JTextArea area = new JTextArea(info);
        JTextField Text = new JTextField(myText);
        JLabel label = new JLabel(myText);
        JPanel panel = new JPanel();

        //panel.add(button);
        //panel.add(Text);
        //panel.add(label);
        panel.add(area);

        return panel;
    }

    /**Check the enviroment variables PROJ_DIR.
     * Check existence of test directoy and other
     * important directories.
     * 
     * Check existence of files needed for this 
     * test.
     * 
     * @return false if any files/dirs not found
     */
    public static boolean setupEnv(String _fullName, String _platform) {

        // environment vars
        String currPath;
        String projEnv;

        boolean fin = true;
        fullName = _fullName;
        platName = _platform;

        // check directories
        projEnv  =  System.getenv("PROJ_DIR");
        currPath = System.getenv("PWD");

        currDir  = new File (currPath);
        projDir  = new File (projEnv);
        tcaseDir = new File (projEnv + "/dv/tb/tests/tcase");
        simDir   = new File (projEnv + "/dv/sim/"+platName+"/"+fullName);
        dataDir  = new File (simDir.getAbsolutePath()+"/log/dbg/data");
        port0Dir = new File(dataDir.getAbsolutePath()+"/port0");
        port1Dir = new File(dataDir.getAbsolutePath()+"/port1");

        System.err.println(simDir);
        
        for(int i=0; i<2; i++)
        {
            ffDepthFile[i] = new File(dataDir.getAbsolutePath()+"/rx_ff_depth_"+i+".log");
            ffPktNumFile[i] = new File(dataDir.getAbsolutePath()+"/rx_ff_pkt_num_"+i+".log");
            dropFifoFullFile[i] = new File(dataDir.getAbsolutePath()+"/rx_pkt_drop_fifo_"+i+".log");
            dropNoDescFile[i] = new File(dataDir.getAbsolutePath()+"/rx_pkt_drop_nodesc_"+i+".log");
            wtrmarkFile[i] = new File(dataDir.getAbsolutePath()+"/rx_wtrmrk_"+i+".log");
            thruPutFile[i] = new File(dataDir.getAbsolutePath()+"/rx_thruput_"+i+".log");
        }

        port0FileName = port0Dir.list();
        port1FileName = port1Dir.list();

        port0File = new File[port0FileName.length];
        port1File = new File[port1FileName.length];

        for (int i=0; i<port0FileName.length; i++)
            port0File[i] = new File(port0Dir.getAbsolutePath()+"/"+port0FileName[i]);

        for (int i=0; i<port1FileName.length; i++)
            port1File[i] = new File(port1Dir.getAbsolutePath()+"/"+port1FileName[i]);

        
        if (fin) {
            for(int i=0; i<2; i++) {
               System.out.println("Found " + ffDepthFile[i].getAbsoluteFile());
               System.out.println("Found " + ffPktNumFile[i].getAbsoluteFile());
               System.out.println("Found " + dropFifoFullFile[i].getAbsoluteFile());
               System.out.println("Found " + dropNoDescFile[i].getAbsoluteFile());
               System.out.println("Found " + wtrmarkFile[i].getAbsoluteFile());
               System.out.println("Found " + thruPutFile[i].getAbsoluteFile());
           }

 	    for (String files : port0FileName)
	         System.out.printf("Found %s\n", port0Dir.getAbsolutePath()+"/"+files);

        for (String files : port1FileName)
            System.out.printf("Found %s\n", port1Dir.getAbsolutePath()+"/"+files);
        }
            
        return fin;
}

  

   /**Generate plots in general for any specific file.
     * Cache files are treated separately.
     *
     * @return
     */
    public Plot multiPlot(List<File> file, String title, String Xlabel, String YLabel)
    {
        Plot newPlot = new Plot();

        try {
            newPlot.clear(true);
            newPlot.setButtons(true);
            
            for (File fileStream : file)
                 newPlot.read(new FileInputStream (fileStream));

            newPlot.setTitle(title);
            newPlot.setXLabel(Xlabel);
            newPlot.setYLabel(YLabel);
            //newPlot.setImpulses(true);
            
        }

        catch (FileNotFoundException ex) {
//            Message msg = new Message("File not found: " + file + " : " + ex);
        }

        catch (IOException ex) {
//            Message msg = new Message("Error reading input: " + file +
//                    " : " + ex);
        }

        return newPlot;
    }

    /**Constructor. Builds JFrame and contents. Port0 will be on
     * on the right side and port1 will be on the left side. There
     * is a combination of 6 plots on each side:
     *  - FIFO Depth
     *  - FIFO packet count
     *  - Drop Count due to FIFO full
     *  - Drop Count due to no descriptors
     *  - Cache behavior of all queues with low watermark settings.
     *  - Throughput is placed at the top of the Frame.
     *
     */

    CacheAnalysis() {

        for (int i=0; i<NUM_PORTS; i++)
        {
            // Add elements
            holders = new ArrayList<File>();
            holders.add(ffDepthFile[i]);
            addEntry(holders, "FIFO Depth Port"+i, "Time (ns)", "128-Byte Word", i);

            if (ffPktNumFile[i].length() > 0) {
               holders = new ArrayList<File>();
               holders.add(ffPktNumFile[i]);
               addEntry(holders, "FIFO Packet Count Port"+i, "Time (ns)", "Packets", i);
            }

            if (dropFifoFullFile[i].length() > 0) {
               holders = new ArrayList<File>();
               holders.add(dropFifoFullFile[i]);
               addEntry(holders, "FIFO Full Drop Count Port"+i, "Time (ns)", "Packets", i);
            }

            if (dropNoDescFile[i].length() > 0) {
                holders = new ArrayList<File>();
                holders.add(dropNoDescFile[i]);
                addEntry(holders, "No Desc. Drop Count Port"+i, "Time (ns)", "Packets", i);
            }

            holders = new ArrayList<File>();

            if (i==0)
                for (File items : port0File)
                    holders.add(items);
            else
                for (File items : port1File)
                    holders.add(items);

           // add water mark as well
           holders.add(wtrmarkFile[i]);
           addEntry(holders, "Cache(s) Utilization Port"+i, "Time (ns)", "Descriptors", i);
        }
        
        setSize(300,800);
        
        // Layout the two plots
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        setLayout(gridbag);

        // Add test info in Column (0)
        c.gridx        = 0;
        c.gridy        = 0;
        c.gridwidth    = 1;
        //c.gridheight   = 3;
        c.fill         = GridBagConstraints.BOTH;
        c.weightx      = 1.0;
        c.weighty      = 1.0;
        gridbag.setConstraints(infoPanel(infoBuffer), c);
        //add(infoPanel(infoBuffer));

        // Add graphs starting from Column(1)
        int i=0;
        int j=0;

        for (Entry _entry : entry)
        {
            // Handle the cache Plot
            c.gridx     = _entry.port+1;
            c.gridy     = (_entry.port == 0) ? i++ : j++;
            c.gridwidth = 1;
            c.fill      = GridBagConstraints.BOTH;
            c.weightx   = 1.0;
            c.weighty   = 1.0;
            Plot mPlot = multiPlot(_entry.file, _entry.title, _entry.Xlabel, _entry.Ylabel);
            gridbag.setConstraints(mPlot,c);
            add(mPlot);
        }
        

        setVisible(true);
    }

    /** parse input and extract needed strings. Name of the test
     *  should have the following shape:
     *  <test>_q<x>s_p<x>_c<x>_gen<x>
     *
     * where,
     * <test> - the name of test base.
     * q<x>s  - x is number of queues.
     * p<x>   - x is number of packets.
     * c<x>   - x is cache setting 0/8 1/16 2/32 3/64
     * gen<x> - x is 0 for gen1 1 for gen2 pcie_mode
     *
     * @param in
     */
    public static boolean parseInput(String in) {

        List<String> port0ConfigList = new ArrayList<String>();
        List<String> port1ConfigList = new ArrayList<String>();
        List<String> globalConfigList = new ArrayList<String>();
        Map <String, String> map;

        String temp[] = null;

        boolean fin = true;

        String configFile = tcaseDir.getAbsolutePath()+"/"+in+".cfg";
        infoBuffer = "Test Name: "+fullName+"\n";

        try {
            BufferedReader inp = new BufferedReader(new FileReader(configFile));

            String line;
            String configLine;

            while ((line = inp.readLine()) != null)
                  if (!line.contains("//") && !line.trim().isEmpty())
                  {
                      configLine = line;
                      
                      if (configLine.contains("_P0"))
                          port0ConfigList.add(configLine);
                      
                      else if (configLine.contains("_P1"))
                               port1ConfigList.add(configLine);
                      else
                          globalConfigList.add(configLine);    
                  }

            for(String lline : port0ConfigList)
            {
                if (lline.contains("RX_NUM_PKTS") ||
                    lline.contains("RX_DC_SIZE")  ||
                    lline.contains("IPG")
                   )
                {
                    temp = lline.split("\\s+");
                    infoBuffer = infoBuffer + lline + "\n";
                }
            }
            //System.out.println (temp[0]+ "    "+temp[1]);

            //System.exit(1);
        }
        catch (IOException e)
        {

        }

        return fin;
    }
    
    /** Shows usage of this script.
     * 
     */

    public static void usage() {
       System.out.print("Please enter the test to analysize\n" +
                        "Test should have to following format in the name:\n" +
                        "       <test>__q<x>s_p<x>_c<x>_gen<x>\n" +
                        " where," +
                        "        <test> - test_name\n" +
                        "        q<x>s  - x is number of queues\n" +
                        "        p<x>   - x is number of packets per queue\n" +
                        "        c<x>   - x is cache size. 0/8 1/16 2/32 3/64\n"+
                        "        gen<x> - x is 0 for pcie gen1; 1 for gen2\n");
    }


    /** main method called in a standalone java application.
     *  We simple instantiate this class, most of the work
     *  happens in the constructor.
     */
    public static void main(String args[]) {

        if (args.length < 2)
            usage();

        else {
            setupEnv(args[0], args[1]);
            parseInput(args[0]);
            
            CacheAnalysis myPlots = new CacheAnalysis();
            myPlots.setDefaultCloseOperation(EXIT_ON_CLOSE);
        }
    }

    
}
